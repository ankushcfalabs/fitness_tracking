import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter_foreground_task/flutter_foreground_task.dart';
import '../theme/app_theme.dart';
import '../models/workout_model.dart';
import '../services/voice_service_new.dart';
import '../services/audio_service.dart';
import '../services/platform_service.dart';
import '../services/background_service.dart';
import '../widgets/common_widgets.dart';

enum TimerPhase { countdown, work, rest, roundBreak, done }

class LiveTimerScreen extends StatefulWidget {
  final Workout workout;
  final void Function(WorkoutHistory) onComplete;

  const LiveTimerScreen({super.key, required this.workout, required this.onComplete});

  @override
  State<LiveTimerScreen> createState() => _LiveTimerScreenState();
}

class _LiveTimerScreenState extends State<LiveTimerScreen> with TickerProviderStateMixin, WidgetsBindingObserver {
  late AnimationController _ringCtrl;
  late AnimationController _pulseCtrl;
  late AnimationController _phaseCtrl;
  late Animation<double> _pulseAnim;
  late Animation<double> _phaseFade;

  Timer? _timer;
  int _secondsLeft = 3;
  int _currentRound = 1;
  int _currentSet = 0;
  TimerPhase _phase = TimerPhase.countdown;
  bool _paused = false;
  int _elapsedSeconds = 0;
  Timer? _elapsedTimer;
  final VoiceServiceNew _voice = VoiceServiceNew();
  final AudioService _audio = AudioService();
  final WorkoutBackgroundService _background = WorkoutBackgroundService();
  bool _voiceEnabled = true;
  bool _soundEnabled = true;
  bool _wasPlayingBeforePause = false;
  bool _completionRecorded = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    
    _ringCtrl = AnimationController(vsync: this, duration: const Duration(seconds: 1));
    _pulseCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 800))
      ..repeat(reverse: true);
    _phaseCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 400));
    _pulseAnim = Tween(begin: 1.0, end: 1.06).animate(
      CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeInOut),
    );
    _phaseFade = CurvedAnimation(parent: _phaseCtrl, curve: Curves.easeOut);
    _phaseCtrl.forward();
    
    _loadSettings();
    _voice.init().then((_) async {
      await _voice.announceWorkoutStart(widget.workout.name, widget.workout.rounds, widget.workout.sets.length);
    });

    _background.init().then((_) {
      // Setup callback for notification button actions
      _background.setActionCallback((action) {
        if (!mounted) return;
        if (action == 'pause' || action == 'resume') {
          _togglePause();
        } else if (action == 'stop') {
          _saveProgressAndExit();
        }
      });
      _background.startWorkout(widget.workout.name);
    });
    _startCountdown();
    _elapsedTimer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (!_paused && _phase != TimerPhase.done) {
        setState(() => _elapsedSeconds++);
        _updateBackgroundNotification();
      }
    });
  }

  Future<void> _loadSettings() async {
    final prefs = await SharedPreferences.getInstance();
    await _audio.init();
    await _voice.init();
    setState(() {
      _voiceEnabled = prefs.getBool('voice_enabled') ?? true;
      _soundEnabled = prefs.getBool('sound_enabled') ?? true;
      _voice.setEnabled(_voiceEnabled);
      _audio.setEnabled(_soundEnabled);
    });
    debugPrint(
      'LiveTimer: Loaded settings - voice: $_voiceEnabled, sound: $_soundEnabled',
    );
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    super.didChangeAppLifecycleState(state);
    if (state == AppLifecycleState.paused) {
      _wasPlayingBeforePause = !_paused;
    } else if (state == AppLifecycleState.resumed) {
      if (_wasPlayingBeforePause && mounted) {
        setState(() {});
      }
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _timer?.cancel();
    _elapsedTimer?.cancel();
    _ringCtrl.dispose();
    _pulseCtrl.dispose();
    _phaseCtrl.dispose();
    _voice.dispose();
    _audio.dispose();
    _background.stopWorkout();
    
    super.dispose();
  }

  void _startCountdown() {
    _secondsLeft = 3;
    _phase = TimerPhase.countdown;
    _startTick();
  }

  void _startTick() {
    _timer?.cancel();
    _ringCtrl.forward(from: 0);
    _timer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (_paused) return;
      setState(() {
        if (_secondsLeft > 1) {
          _secondsLeft--;
          _ringCtrl.forward(from: 0);
          if (PlatformService.supportsHapticFeedback) {
            HapticFeedback.lightImpact();
          }
          if (_phase == TimerPhase.countdown) {
            _voice.announceCountdown(_secondsLeft);
            _audio.playCountdownBeep();
          } else if (_phase == TimerPhase.work) {
            final duration = widget.workout.sets[_currentSet].durationSeconds;
            if (_secondsLeft == duration ~/ 2 && duration >= 20) {
              _voice.announceHalfway();
              _audio.playHalfwayBeep();
            } else if (_secondsLeft == 10 || _secondsLeft == 5 || _secondsLeft <= 3) {
              _voice.announceTimeRemaining(_secondsLeft);
              if (_secondsLeft <= 3) _audio.playWarningBeep();
            }
          } else if (_secondsLeft <= 3) {
            _voice.announceTimeRemaining(_secondsLeft);
            _audio.playWarningBeep();
          }
        } else {
          _advance();
        }
      });
    });
  }

  void _advance() {
    _phaseCtrl.reset();
    _phaseCtrl.forward();
    if (PlatformService.supportsHapticFeedback) {
      HapticFeedback.mediumImpact();
    }

    if (_phase == TimerPhase.countdown) {
      _phase = TimerPhase.work;
      _currentSet = 0;
      _secondsLeft = widget.workout.sets[_currentSet].durationSeconds;
      _ringCtrl.forward(from: 0);
      _voice.announceRoundStart(_currentRound, widget.workout.rounds);
      final setName = widget.workout.sets[_currentSet].name.isNotEmpty
          ? widget.workout.sets[_currentSet].name
          : 'Set ${_currentSet + 1}';
      _voice.announceSetStart(setName);
      // Small delay before beep to avoid audio conflict
      Future.delayed(const Duration(milliseconds: 300), () {
        _audio.playStartBeep();
      });
      return;
    }

    if (_phase == TimerPhase.work) {
      final setName = widget.workout.sets[_currentSet].name.isNotEmpty
          ? widget.workout.sets[_currentSet].name
          : 'Set ${_currentSet + 1}';
      _voice.announceSetEnd(setName);
      final breakTime = widget.workout.sets[_currentSet].breakSeconds;
      if (breakTime > 0) {
        _phase = TimerPhase.rest;
        _secondsLeft = breakTime;
        _ringCtrl.forward(from: 0);
        _voice.announceRest(breakTime);
        _audio.playEndBeep();
        return;
      }
      _nextSet();
      return;
    }

    if (_phase == TimerPhase.rest) {
      _nextSet();
      return;
    }

    if (_phase == TimerPhase.roundBreak) {
      _currentRound++;
      _currentSet = 0;
      _phase = TimerPhase.work;
      _secondsLeft = widget.workout.sets[_currentSet].durationSeconds;
      _ringCtrl.forward(from: 0);
      _voice.announceRoundStart(_currentRound, widget.workout.rounds);
      final setName = widget.workout.sets[_currentSet].name.isNotEmpty
          ? widget.workout.sets[_currentSet].name
          : 'Set ${_currentSet + 1}';
      _voice.announceSetStart(setName);
      _audio.playStartBeep();
      return;
    }
  }

  void _nextSet() {
    if (_currentSet < widget.workout.sets.length - 1) {
      _currentSet++;
      _phase = TimerPhase.work;
      _secondsLeft = widget.workout.sets[_currentSet].durationSeconds;
      _ringCtrl.forward(from: 0);
      final setName = widget.workout.sets[_currentSet].name.isNotEmpty
          ? widget.workout.sets[_currentSet].name
          : 'Set ${_currentSet + 1}';
      _voice.announceSetStart(setName);
      _audio.playStartBeep();
    } else if (_currentRound < widget.workout.rounds) {
      _voice.announceRoundEnd(_currentRound, widget.workout.rounds);
      _phase = TimerPhase.roundBreak;
      _secondsLeft = widget.workout.roundBreakSeconds;
      _ringCtrl.forward(from: 0);
      _voice.announceRoundBreak(widget.workout.roundBreakSeconds, _currentRound + 1, widget.workout.rounds);
      _audio.playRoundCompleteBeep();
    } else {
      _phase = TimerPhase.done;
      _timer?.cancel();
      if (PlatformService.supportsHapticFeedback) {
        HapticFeedback.heavyImpact();
      }
      _voice.announceWorkoutComplete(widget.workout.name, _elapsedSeconds);
      _audio.playSuccessChime();
      _onWorkoutDone();
    }
  }

  void _onWorkoutDone() {
    if (_completionRecorded) return;
    _completionRecorded = true;
    _background.stopWorkout();
    widget.onComplete(WorkoutHistory(
      workoutName: widget.workout.name,
      date: DateTime.now(),
      durationSeconds: _elapsedSeconds,
      roundsCompleted: _currentRound,
      emoji: widget.workout.emoji,
    ));
  }

  void _saveProgressAndExit() {
    _timer?.cancel();
    _elapsedTimer?.cancel();
    _onWorkoutDone();
    if (mounted) {
      Navigator.maybePop(context);
    }
  }
  
  void _updateBackgroundNotification() {
    // Only update notification when app is in background
    if (WidgetsBinding.instance.lifecycleState != AppLifecycleState.resumed) {
      final timeStr = '${_secondsLeft ~/ 60}:${(_secondsLeft % 60).toString().padLeft(2, '0')}';
      _background.updateNotification(
        phase: _phaseLabel,
        timeRemaining: timeStr,
        round: _currentRound,
        totalRounds: widget.workout.rounds,
        isPaused: _paused,
      );
    }
  }

  void _togglePause() {
    setState(() => _paused = !_paused);
    if (PlatformService.supportsHapticFeedback) {
      HapticFeedback.selectionClick();
    }
    if (_paused) {
      _voice.announcePaused();
    } else {
      _voice.announceResumed();
      _ringCtrl.forward(from: 0);
    }
    // Update notification immediately to reflect pause state
    _updateBackgroundNotification();
  }

  void _skip() {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: AppColors.surface,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: const Text('Skip Phase?', style: TextStyle(color: AppColors.textPrimary)),
        content: Text(
          _phase == TimerPhase.work
              ? 'Skip to rest period'
              : _phase == TimerPhase.rest
                  ? 'Skip to next set'
                  : 'Skip to next phase',
          style: const TextStyle(color: AppColors.textSecondary),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel', style: TextStyle(color: AppColors.textSecondary)),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              if (PlatformService.supportsHapticFeedback) {
                HapticFeedback.mediumImpact();
              }
              setState(() {
                _secondsLeft = 1;
                _advance();
              });
            },
            style: ElevatedButton.styleFrom(backgroundColor: AppColors.accent),
            child: const Text('Skip'),
          ),
        ],
      ),
    );
  }

  void _end() {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: AppColors.surface,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: const Text('End Workout?', style: TextStyle(color: AppColors.textPrimary)),
        content: const Text(
          'Your progress will be saved.',
          style: TextStyle(color: AppColors.textSecondary),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel', style: TextStyle(color: AppColors.textSecondary)),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              _saveProgressAndExit();
            },
            style: ElevatedButton.styleFrom(backgroundColor: AppColors.accentOrange),
            child: const Text('End'),
          ),
        ],
      ),
    );
  }

  int get _totalPhaseDuration {
    switch (_phase) {
      case TimerPhase.countdown:
        return 3;
      case TimerPhase.work:
        return widget.workout.sets[_currentSet].durationSeconds;
      case TimerPhase.rest:
        return widget.workout.sets[_currentSet].breakSeconds;
      case TimerPhase.roundBreak:
        return widget.workout.roundBreakSeconds;
      case TimerPhase.done:
        return 1;
    }
  }

  double get _progress =>
      _phase == TimerPhase.done ? 1.0 : 1.0 - (_secondsLeft / _totalPhaseDuration);

  Color get _phaseColor {
    switch (_phase) {
      case TimerPhase.countdown:
        return AppColors.accentPurple;
      case TimerPhase.work:
        return AppColors.accentGreen;
      case TimerPhase.rest:
        return AppColors.accent;
      case TimerPhase.roundBreak:
        return AppColors.accentOrange;
      case TimerPhase.done:
        return AppColors.accentGreen;
    }
  }

  String get _phaseLabel {
    switch (_phase) {
      case TimerPhase.countdown:
        return 'GET READY';
      case TimerPhase.work:
        return 'WORK';
      case TimerPhase.rest:
        return 'REST';
      case TimerPhase.roundBreak:
        return 'ROUND BREAK';
      case TimerPhase.done:
        return 'DONE! 🎉';
    }
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    final isWide = size.width > 700;

    return WithForegroundTask(
      child: Scaffold(
        backgroundColor: AppColors.bg,
        body: SafeArea(
          child: _phase == TimerPhase.done
              ? _buildDoneScreen()
              : isWide
                  ? _buildWideLayout()
                  : _buildNarrowLayout(),
        ),
      ),
    );
  }

  Widget _buildNarrowLayout() => Column(
        children: [
          _buildTopBar(),
          Expanded(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                _buildPhaseLabel(),
                const SizedBox(height: 32),
                _buildTimerRing(),
                const SizedBox(height: 32),
                _buildRoundSetInfo(),
                const SizedBox(height: 16),
                _buildProgressBar(),
              ],
            ),
          ),
          _buildControls(),
          const SizedBox(height: 24),
        ],
      );

  Widget _buildWideLayout() => Column(
        children: [
          _buildTopBar(),
          Expanded(
            child: Row(
              children: [
                Expanded(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      _buildPhaseLabel(),
                      const SizedBox(height: 32),
                      _buildTimerRing(),
                    ],
                  ),
                ),
                Expanded(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      _buildRoundSetInfo(),
                      const SizedBox(height: 24),
                      _buildProgressBar(),
                      const SizedBox(height: 40),
                      _buildControls(),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      );

  Widget _buildTopBar() => Padding(
        padding: const EdgeInsets.fromLTRB(16, 16, 16, 0),
        child: Row(
          children: [
            GestureDetector(
              onTap: _end,
              child: ModernTooltip(
                message: 'End workout',
                child: Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: AppColors.card,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: const Icon(Icons.close_rounded, color: AppColors.textPrimary, size: 22),
                ),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                widget.workout.name,
                style: const TextStyle(
                  color: AppColors.textPrimary,
                  fontSize: 18,
                  fontWeight: FontWeight.w700,
                ),
                textAlign: TextAlign.center,
              ),
            ),
            GestureDetector(
              onTap: () => setState(() {
                _voiceEnabled = !_voiceEnabled;
                _voice.setEnabled(_voiceEnabled);
              }),
              child: ModernTooltip(
                message: _voiceEnabled ? 'Mute voice' : 'Unmute voice',
                child: Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: AppColors.card,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Icon(
                    _voiceEnabled ? Icons.volume_up_rounded : Icons.volume_off_rounded,
                    color: _voiceEnabled ? AppColors.accent : AppColors.textSecondary,
                    size: 22,
                  ),
                ),
              ),
            ),
            const SizedBox(width: 8),
            GestureDetector(
              onTap: () => setState(() {
                _soundEnabled = !_soundEnabled;
                _audio.setEnabled(_soundEnabled);
              }),
              child: ModernTooltip(
                message: _soundEnabled ? 'Mute sounds' : 'Unmute sounds',
                child: Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: AppColors.card,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Icon(
                    _soundEnabled ? Icons.notifications_active_rounded : Icons.notifications_off_rounded,
                    color: _soundEnabled ? AppColors.accentGreen : AppColors.textSecondary,
                    size: 22,
                  ),
                ),
              ),
            ),
          ],
        ),
      );

  Widget _buildPhaseLabel() => FadeTransition(
        opacity: _phaseFade,
        child: Column(
          children: [
            AnimatedContainer(
              duration: const Duration(milliseconds: 300),
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 10),
              decoration: BoxDecoration(
                color: _phaseColor.withValues(alpha: 0.15),
                borderRadius: BorderRadius.circular(30),
                border: Border.all(color: _phaseColor.withValues(alpha: 0.4)),
              ),
              child: Text(
                _phaseLabel,
                style: TextStyle(
                  color: _phaseColor,
                  fontSize: 14,
                  fontWeight: FontWeight.w800,
                  letterSpacing: 2,
                ),
              ),
            ),
            if (_phase == TimerPhase.work && _secondsLeft > 5) ...[
              const SizedBox(height: 12),
              Text(
                _getMotivationalTip(),
                style: const TextStyle(
                  color: AppColors.textSecondary,
                  fontSize: 12,
                  fontStyle: FontStyle.italic,
                ),
                textAlign: TextAlign.center,
              ),
            ],
          ],
        ),
      );

  String _getMotivationalTip() {
    final tips = [
      'Keep your core engaged',
      'Focus on your breathing',
      'Maintain proper form',
      'You\'ve got this!',
      'Stay strong',
      'Push through',
      'Almost there',
      'Feel the burn',
    ];
    return tips[(_currentSet + _currentRound) % tips.length];
  }

  Widget _buildTimerRing() {
    final ringSize = min(MediaQuery.of(context).size.width * 0.72, 300.0);

    return ScaleTransition(
      scale: _pulseAnim,
      child: SizedBox(
        width: ringSize,
        height: ringSize,
        child: Stack(
          alignment: Alignment.center,
          children: [
            CustomPaint(
              size: Size(ringSize, ringSize),
              painter: _RingPainter(
                progress: _progress,
                color: _phaseColor,
                bgColor: _phaseColor.withValues(alpha: 0.1),
                strokeWidth: 12,
              ),
            ),
            Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                AnimatedSwitcher(
                  duration: const Duration(milliseconds: 200),
                  transitionBuilder: (child, anim) => ScaleTransition(scale: anim, child: child),
                  child: Text(
                    _phase == TimerPhase.countdown
                        ? '$_secondsLeft'
                        : '${_secondsLeft ~/ 60}:${(_secondsLeft % 60).toString().padLeft(2, '0')}',
                    key: ValueKey(_secondsLeft),
                    style: TextStyle(
                      color: AppColors.textPrimary,
                      fontSize: ringSize * 0.28,
                      fontWeight: FontWeight.w900,
                      fontFeatures: const [FontFeature.tabularFigures()],
                    ),
                  ),
                ),
                if (_paused)
                  const Text(
                    'PAUSED',
                    style: TextStyle(
                      color: AppColors.textSecondary,
                      fontSize: 13,
                      letterSpacing: 2,
                    ),
                  ),
                if (!_paused && _phase == TimerPhase.work) ...[
                  const SizedBox(height: 4),
                  Text(
                    widget.workout.sets[_currentSet].name.isNotEmpty
                        ? widget.workout.sets[_currentSet].name
                        : 'Set ${_currentSet + 1}',
                    style: const TextStyle(
                      color: AppColors.textSecondary,
                      fontSize: 13,
                      letterSpacing: 1,
                    ),
                  ),
                ],
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildRoundSetInfo() => Padding(
        padding: const EdgeInsets.symmetric(horizontal: 32),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            _infoBlock('Round', '$_currentRound / ${widget.workout.rounds}', AppColors.accentOrange),
            Container(width: 1, height: 40, color: AppColors.divider),
            _infoBlock(
              'Set',
              _phase == TimerPhase.work || _phase == TimerPhase.rest
                  ? '${_currentSet + 1} / ${widget.workout.sets.length}'
                  : '-',
              AppColors.accent,
            ),
            Container(width: 1, height: 40, color: AppColors.divider),
            _infoBlock(
              'Elapsed',
              '${_elapsedSeconds ~/ 60}:${(_elapsedSeconds % 60).toString().padLeft(2, '0')}',
              AppColors.accentGreen,
            ),
          ],
        ),
      );

  Widget _infoBlock(String label, String value, Color color) => Column(
        children: [
          Text(label, style: const TextStyle(color: AppColors.textSecondary, fontSize: 12)),
          const SizedBox(height: 4),
          Text(
            value,
            style: TextStyle(color: color, fontSize: 20, fontWeight: FontWeight.w800),
          ),
        ],
      );

  Widget _buildProgressBar() {
    final totalSets = widget.workout.sets.length * widget.workout.rounds;
    final completedSets = (_currentRound - 1) * widget.workout.sets.length + _currentSet;
    final overallProgress = totalSets > 0 ? completedSets / totalSets : 0.0;

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 32),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text('Overall Progress', style: TextStyle(color: AppColors.textSecondary, fontSize: 12)),
              Text(
                '${(overallProgress * 100).toInt()}%',
                style: const TextStyle(color: AppColors.textPrimary, fontSize: 12, fontWeight: FontWeight.w600),
              ),
            ],
          ),
          const SizedBox(height: 8),
          ClipRRect(
            borderRadius: BorderRadius.circular(4),
            child: LinearProgressIndicator(
              value: overallProgress,
              backgroundColor: AppColors.card,
              valueColor: AlwaysStoppedAnimation(_phaseColor),
              minHeight: 6,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildControls() => Padding(
        padding: const EdgeInsets.symmetric(horizontal: 32),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            _controlBtn(
              icon: Icons.stop_rounded,
              color: AppColors.accentOrange,
              onTap: _end,
              size: 52,
            ),
            const SizedBox(width: 16),
            _controlBtn(
              icon: _paused ? Icons.play_arrow_rounded : Icons.pause_rounded,
              color: _phaseColor,
              onTap: _togglePause,
              size: 72,
              primary: true,
            ),
            const SizedBox(width: 16),
            _controlBtn(
              icon: Icons.skip_next_rounded,
              color: AppColors.textSecondary,
              onTap: _skip,
              size: 52,
            ),
          ],
        ),
      );

  Widget _controlBtn({
    required IconData icon,
    required Color color,
    required VoidCallback onTap,
    required double size,
    bool primary = false,
  }) =>
      GestureDetector(
        onTap: onTap,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 150),
          width: size,
          height: size,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: primary ? color : AppColors.card,
            border: primary ? null : Border.all(color: color.withValues(alpha: 0.3)),
            boxShadow: primary
                ? [BoxShadow(color: color.withValues(alpha: 0.4), blurRadius: 20, spreadRadius: 2)]
                : null,
          ),
          child: Icon(
            icon,
            color: primary ? AppColors.bg : color,
            size: size * 0.45,
          ),
        ),
      );

  Widget _buildDoneScreen() {
    return TweenAnimationBuilder<double>(
      tween: Tween(begin: 0, end: 1),
      duration: const Duration(milliseconds: 600),
      curve: Curves.easeOutBack,
      builder: (_, v, child) => Opacity(opacity: v.clamp(0, 1), child: Transform.scale(scale: v.clamp(0.8, 1.0), child: child)),
      child: Center(
        child: Padding(
          padding: const EdgeInsets.all(32),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Text('🎉', style: TextStyle(fontSize: 80)),
              const SizedBox(height: 24),
              const Text(
                'Workout Complete!',
                style: TextStyle(
                  color: AppColors.textPrimary,
                  fontSize: 32,
                  fontWeight: FontWeight.w900,
                ),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 12),
              Text(
                widget.workout.name,
                style: const TextStyle(color: AppColors.textSecondary, fontSize: 16),
              ),
              const SizedBox(height: 40),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  _doneStatCard('Rounds', '${widget.workout.rounds}', AppColors.accentOrange),
                  const SizedBox(width: 16),
                  _doneStatCard(
                    'Time',
                    '${_elapsedSeconds ~/ 60}:${(_elapsedSeconds % 60).toString().padLeft(2, '0')}',
                    AppColors.accentGreen,
                  ),
                  const SizedBox(width: 16),
                  _doneStatCard(
                    'Sets',
                    '${widget.workout.sets.length * widget.workout.rounds}',
                    AppColors.accent,
                  ),
                ],
              ),
              const SizedBox(height: 48),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: () => Navigator.pop(context),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppColors.accentGreen,
                    foregroundColor: AppColors.bg,
                    padding: const EdgeInsets.symmetric(vertical: 18),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                  ),
                  child: const Text('Back to Home', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _doneStatCard(String label, String value, Color color) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
        decoration: BoxDecoration(
          color: color.withValues(alpha: 0.1),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: color.withValues(alpha: 0.3)),
        ),
        child: Column(
          children: [
            Text(value, style: TextStyle(color: color, fontSize: 24, fontWeight: FontWeight.w800)),
            const SizedBox(height: 4),
            Text(label, style: const TextStyle(color: AppColors.textSecondary, fontSize: 12)),
          ],
        ),
      );
}

class _RingPainter extends CustomPainter {
  final double progress;
  final Color color;
  final Color bgColor;
  final double strokeWidth;

  const _RingPainter({
    required this.progress,
    required this.color,
    required this.bgColor,
    required this.strokeWidth,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = (size.width - strokeWidth) / 2;
    final paint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = strokeWidth
      ..strokeCap = StrokeCap.round;

    paint.color = bgColor;
    canvas.drawCircle(center, radius, paint);

    final clampedProgress = progress.clamp(0.0, 1.0);
    if (clampedProgress > 0.001) {
      final sweepAngle = 2 * pi * clampedProgress;
      
      paint.shader = SweepGradient(
        startAngle: -pi / 2,
        endAngle: -pi / 2 + sweepAngle,
        colors: [color.withValues(alpha: 0.6), color],
        tileMode: TileMode.clamp,
      ).createShader(Rect.fromCircle(center: center, radius: radius));

      canvas.drawArc(
        Rect.fromCircle(center: center, radius: radius),
        -pi / 2,
        sweepAngle,
        false,
        paint,
      );
    }
  }

  @override
  bool shouldRepaint(_RingPainter old) =>
      old.progress != progress || old.color != color;
}
