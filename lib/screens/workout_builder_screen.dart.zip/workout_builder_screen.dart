import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../theme/app_theme.dart';
import '../models/workout_model.dart';
import '../widgets/common_widgets.dart';
import '../services/validation_service.dart';

class WorkoutBuilderScreen extends StatefulWidget {
  final Workout? workout;
  final void Function(Workout)? onSave;
  final bool embedded;

  const WorkoutBuilderScreen({
    super.key,
    this.workout,
    this.onSave,
    this.embedded = false,
  });

  @override
  State<WorkoutBuilderScreen> createState() => _WorkoutBuilderScreenState();
}

class _WorkoutBuilderScreenState extends State<WorkoutBuilderScreen>
    with SingleTickerProviderStateMixin {
  late TextEditingController _nameCtrl;
  late int _rounds;
  late int _roundBreak;
  late List<WorkoutSet> _sets;
  late String _emoji;
  late String _category;
  late AnimationController _fadeCtrl;
  late Animation<double> _fadeAnim;

  final _emojis = ['💪', '🔥', '⚡', '🏋️', '🌟', '🚀', '🎯', '🏃', '🥊', '🧘'];
  final _categories = ['Custom', 'HIIT', 'Tabata', 'Circuit', 'Beginner'];

  @override
  void initState() {
    super.initState();
    final w = widget.workout;
    _nameCtrl = TextEditingController(text: w?.name ?? '');
    _rounds = w?.rounds ?? 3;
    _roundBreak = w?.roundBreakSeconds ?? 60;
    _sets = w?.sets.map((s) => s.copyWith()).toList() ??
        [const WorkoutSet(durationSeconds: 30, breakSeconds: 10)];
    _emoji = w?.emoji ?? '💪';
    _category = w?.category ?? 'Custom';
    _fadeCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 500));
    _fadeAnim = CurvedAnimation(parent: _fadeCtrl, curve: Curves.easeOut);
    _fadeCtrl.forward();
  }

  @override
  void dispose() {
    _nameCtrl.dispose();
    _fadeCtrl.dispose();
    super.dispose();
  }

  void _save() {
    if (_nameCtrl.text.trim().isEmpty) {
      ErrorSnackBar.show(context, 'Please enter a workout name');
      return;
    }

    if (_nameCtrl.text.trim().length > 30) {
      ErrorSnackBar.show(context, 'Workout name is too long (max 30 characters)');
      return;
    }

    if (_sets.isEmpty) {
      ErrorSnackBar.show(context, 'Please add at least one set');
      return;
    }

    if (_sets.length > 20) {
      ErrorSnackBar.show(context, 'Too many sets (max 20 sets)');
      return;
    }

    final workout = Workout(
      id: widget.workout?.id ?? DateTime.now().millisecondsSinceEpoch.toString(),
      name: _nameCtrl.text.trim(),
      category: _category,
      rounds: _rounds,
      sets: _sets,
      roundBreakSeconds: _roundBreak,
      emoji: _emoji,
    );

    // Validate and sanitize workout data
    if (!ValidationService.isValidWorkout(workout)) {
      String errorMsg = 'Invalid workout configuration';

      // Check specific validation failures
      if (_rounds < 1 || _rounds > 50) {
        errorMsg = 'Rounds must be between 1 and 50';
      } else if (_roundBreak < 0 || _roundBreak > 600) {
        errorMsg = 'Round break must be between 0 and 600 seconds';
      } else {
        // Check sets validation
        for (int i = 0; i < _sets.length; i++) {
          final set = _sets[i];
          if (set.durationSeconds < 5 || set.durationSeconds > 7200) {
            errorMsg = 'Set ${i + 1}: Work time must be between 5 seconds and 2 hours';
            break;
          } else if (set.breakSeconds < 0 || set.breakSeconds > 7200) {
            errorMsg = 'Set ${i + 1}: Break time must be between 0 and 2 hours';
            break;
          } else if (set.name.length > 50) {
            errorMsg = 'Set ${i + 1}: Name is too long (max 50 characters)';
            break;
          }
        }
      }

      ErrorSnackBar.show(context, errorMsg);
      return;
    }

    final sanitizedWorkout = ValidationService.sanitizeWorkout(workout);

    if (widget.embedded && widget.onSave != null) {
      widget.onSave!(sanitizedWorkout);
      SuccessSnackBar.show(context, widget.workout == null ?  'Workout saved successfully!' :  'Workout updated successfully!');
      _resetForm();
    } else {
      Navigator.pop(context, sanitizedWorkout);
      SuccessSnackBar.show(context,  widget.workout == null ?  'Workout saved successfully!' :  'Workout updated successfully!');

    }
  }

  void _resetForm() {
    _nameCtrl.clear();
    setState(() {
      _rounds = 3;
      _roundBreak = 60;
      _sets = [const WorkoutSet(durationSeconds: 30, breakSeconds: 10)];
      _emoji = '💪';
      _category = 'Custom';
    });
  }

  @override
  Widget build(BuildContext context) {
    return FadeTransition(
      opacity: _fadeAnim,
      child: widget.embedded ? _buildBody() : Scaffold(
        backgroundColor: AppColors.bg,
        appBar: AppBar(
          centerTitle: false,
          title: Text(widget.workout == null ? 'New Workout' : 'Edit Workout',style: TextStyle(
            color: AppColors.textPrimary,
            fontSize: 22,
            fontWeight: FontWeight.w800,
          ),),
          actions: [
            Padding(
              padding: const EdgeInsets.only(right: 8),
              child: AnimatedGradientButton(
                label: 'Save',
                icon: Icons.check_rounded,
                onTap: _save,
                colors: const [AppColors.accentGreen, AppColors.accent],
              ),
              // TextButton.icon(
              //   onPressed: _save,
              //   icon: const Icon(Icons.check_rounded, color: AppColors.accent, size: 20),
              //   label: const Text('Save', style: TextStyle(color: AppColors.accent, fontWeight: FontWeight.w700)),
              //   style: TextButton.styleFrom(
              //     padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              //   ),
              // ),
            ),
          ],
        ),
        body: _buildBody(),
      ),
    );
  }

  Widget _buildBody() => CustomScrollView(
        slivers: [
          if (widget.embedded)
            SliverToBoxAdapter(
              child: Padding(
                padding: EdgeInsets.fromLTRB(20, MediaQuery.of(context).padding.top + 20, 20, 0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text(
                      'Builder',
                      style: TextStyle(
                        color: AppColors.textPrimary,
                        fontSize: 28,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    AnimatedGradientButton(
                      label: 'Save',
                      icon: Icons.check_rounded,
                      onTap: _save,
                      colors: const [AppColors.accentGreen, AppColors.accent],
                    ),
                  ],
                ),
              ),
            ),
          SliverToBoxAdapter(child: _buildEmojiPicker()),
          SliverToBoxAdapter(child: _buildNameField()),
          SliverToBoxAdapter(child: _buildCategoryPicker()),
          SliverToBoxAdapter(child: _buildRoundsSection()),
          SliverToBoxAdapter(child: _buildSetsSection()),
          SliverToBoxAdapter(child: _buildRoundBreakSection()),
          SliverToBoxAdapter(child: _buildSummary()),
          const SliverToBoxAdapter(child: SizedBox(height: 100)),
        ],
      );

  Widget _buildEmojiPicker() => Padding(
        padding: const EdgeInsets.fromLTRB(20, 20, 20, 0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Icon', style: TextStyle(color: AppColors.textSecondary, fontSize: 13)),
            const SizedBox(height: 10),
            SizedBox(
              height: 52,
              child: ListView.separated(
                scrollDirection: Axis.horizontal,
                itemCount: _emojis.length,
                separatorBuilder: (_, __) => const SizedBox(width: 8),
                itemBuilder: (_, i) => GestureDetector(
                  onTap: () => setState(() => _emoji = _emojis[i]),
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 200),
                    width: 52,
                    height: 52,
                    decoration: BoxDecoration(
                      color: _emoji == _emojis[i]
                          ? AppColors.accent.withValues(alpha: 0.2)
                          : AppColors.card,
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(
                        color: _emoji == _emojis[i] ? AppColors.accent : AppColors.divider,
                        width: 1.5,
                      ),
                    ),
                    child: Center(
                      child: Text(_emojis[i], style: const TextStyle(fontSize: 24)),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      );

  Widget _buildNameField() => Padding(
        padding: const EdgeInsets.fromLTRB(20, 20, 20, 0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Workout Name', style: TextStyle(color: AppColors.textSecondary, fontSize: 13)),
            const SizedBox(height: 8),
            TextField(
              controller: _nameCtrl,
              style: const TextStyle(color: AppColors.textPrimary, fontSize: 16),
              decoration: InputDecoration(
                hintText: 'e.g. Morning HIIT',
                hintStyle: const TextStyle(color: AppColors.textSecondary),
                errorText: _nameCtrl.text.length > 30 ? 'Name too long (max 30 characters)' : null,
                counterText: '${_nameCtrl.text.length}/30',
                counterStyle: TextStyle(
                  color: _nameCtrl.text.length > 30 ? AppColors.error : AppColors.textSecondary,
                  fontSize: 11,
                ),
              ),
              inputFormatters: [LengthLimitingTextInputFormatter(30)],
              onChanged: (_) => setState(() {}),
            ),
          ],
        ),
      );

  Widget _buildCategoryPicker() => Padding(
        padding: const EdgeInsets.fromLTRB(20, 20, 20, 0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Category', style: TextStyle(color: AppColors.textSecondary, fontSize: 13)),
            const SizedBox(height: 10),
            SizedBox(
              height: 36,
              child: ListView.separated(
                scrollDirection: Axis.horizontal,
                itemCount: _categories.length,
                separatorBuilder: (_, __) => const SizedBox(width: 8),
                itemBuilder: (_, i) => WorkoutCategoryChip(
                  label: _categories[i],
                  selected: _category == _categories[i],
                  onTap: () => setState(() => _category = _categories[i]),
                ),
              ),
            ),
          ],
        ),
      );

  Widget _buildRoundsSection() => Padding(
        padding: const EdgeInsets.fromLTRB(20, 24, 20, 0),
        child: _sectionCard(
          title: 'Rounds',
          icon: Icons.repeat_rounded,
          color: AppColors.accentOrange,
          child: _stepper(
            value: _rounds,
            min: 1,
            max: 20,
            onChanged: (v) => setState(() => _rounds = v),
          ),
        ),
      );

  Widget _buildRoundBreakSection() => Padding(
        padding: const EdgeInsets.fromLTRB(20, 16, 20, 0),
        child: _sectionCard(
          title: 'Break Between Rounds',
          icon: Icons.coffee_rounded,
          color: AppColors.accentPurple,
          child: _durationPicker(
            value: _roundBreak,
            onChanged: (v) => setState(() => _roundBreak = v),
          ),
        ),
      );

   Widget _buildSetsSection() => Padding(
         padding: const EdgeInsets.fromLTRB(20, 16, 20, 0),
         child: Column(
           crossAxisAlignment: CrossAxisAlignment.start,
           children: [
             Row(
               mainAxisAlignment: MainAxisAlignment.spaceBetween,
               children: [
                 Row(
                   children: [
                     Container(
                       padding: const EdgeInsets.all(8),
                       decoration: BoxDecoration(
                         color: AppColors.accentGreen.withValues(alpha: 0.12),
                         borderRadius: BorderRadius.circular(10),
                       ),
                       child: const Icon(Icons.layers_rounded, color: AppColors.accentGreen, size: 18),
                     ),
                     const SizedBox(width: 10),
                     const Text(
                       'Sets',
                       style: TextStyle(
                         color: AppColors.textPrimary,
                         fontSize: 17,
                         fontWeight: FontWeight.w700,
                       ),
                     ),
                   ],
                 ),
                 GestureDetector(
                   onTap: _sets.length < 20 ? () => setState(() => _sets.add(const WorkoutSet())) : null,
                   child: Opacity(
                     opacity: _sets.length < 20 ? 1.0 : 0.5,
                     child: Container(
                       padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                       decoration: BoxDecoration(
                         color: AppColors.accentGreen.withValues(alpha: 0.12),
                         borderRadius: BorderRadius.circular(12),
                         border: Border.all(color: AppColors.accentGreen.withValues(alpha: 0.18)),
                       ),
                       child: const Row(
                         children: [
                           Icon(Icons.add_rounded, color: AppColors.accentGreen, size: 16),
                           SizedBox(width: 4),
                           Text('Add Set', style: TextStyle(color: AppColors.accentGreen, fontSize: 13, fontWeight: FontWeight.w700)),
                         ],
                       ),
                     ),
                   ),
                 ),
               ],
             ),
            const SizedBox(height: 12),
            ...List.generate(
              _sets.length,
              (i) => _SetCard(
                index: i,
                set: _sets[i],
                canDelete: _sets.length > 1,
                onChanged: (s) => setState(() => _sets[i] = s),
                onDelete: () => setState(() => _sets.removeAt(i)),
              ),
            ),
          ],
        ),
      );

  Widget _buildSummary() {
    final preview = Workout(
      id: 'preview',
      name: _nameCtrl.text.isEmpty ? 'Workout' : _nameCtrl.text,
      rounds: _rounds,
      sets: _sets,
      roundBreakSeconds: _roundBreak,
      emoji: _emoji,
    );

     return Padding(
       padding: const EdgeInsets.fromLTRB(20, 24, 20, 0),
       child: Container(
         padding: const EdgeInsets.all(18),
         decoration: BoxDecoration(
           color: AppColors.surface,
           borderRadius: BorderRadius.circular(20),
           border: Border.all(color: AppColors.divider),
           boxShadow: const [
             BoxShadow(color: Color(0x0A000000), blurRadius: 16, offset: Offset(0, 8)),
           ],
         ),
        child: Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                _summaryItem('Total Time', preview.totalDuration, AppColors.accent),
                Container(width: 1, height: 40, color: AppColors.divider),
                _summaryItem('Sets', '${_sets.length}', AppColors.accentGreen),
                Container(width: 1, height: 40, color: AppColors.divider),
                _summaryItem('Rounds', '$_rounds', AppColors.accentOrange),
              ],
            ),
            const SizedBox(height: 16),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
              decoration: BoxDecoration(
                color: preview.difficultyColor.withValues(alpha: 0.1),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: preview.difficultyColor.withValues(alpha: 0.3)),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.fitness_center_rounded, color: preview.difficultyColor, size: 16),
                  const SizedBox(width: 8),
                  Text(
                    'Difficulty: ${preview.difficulty}',
                    style: TextStyle(
                      color: preview.difficultyColor,
                      fontSize: 13,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _summaryItem(String label, String value, Color color) => Column(
        children: [
          Text(value, style: TextStyle(color: color, fontSize: 22, fontWeight: FontWeight.w800)),
          const SizedBox(height: 4),
          Text(label, style: const TextStyle(color: AppColors.textSecondary, fontSize: 12)),
        ],
      );

   Widget _sectionCard({
     required String title,
     required IconData icon,
     required Color color,
     required Widget child,
   }) =>
       Container(
         padding: const EdgeInsets.all(16),
         decoration: BoxDecoration(
           color: AppColors.surface,
           borderRadius: BorderRadius.circular(18),
           border: Border.all(color: AppColors.divider),
         ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: color.withValues(alpha: 0.15),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Icon(icon, color: color, size: 18),
            ),
            const SizedBox(width: 12),
            Text(
              title,
              style: const TextStyle(
                color: AppColors.textPrimary,
                fontSize: 15,
                fontWeight: FontWeight.w600,
              ),
            ),
            const Spacer(),
            child,
          ],
        ),
      );

  Widget _stepper({
    required int value,
    required int min,
    required int max,
    required void Function(int) onChanged,
  }) =>
      Row(
        children: [
          _stepBtn(Icons.remove_rounded, value > min, () {
            if (value > min) onChanged(value - 1);
          }),
          const SizedBox(width: 12),
          Text(
            '$value',
            style: const TextStyle(
              color: AppColors.textPrimary,
              fontSize: 20,
              fontWeight: FontWeight.w800,
            ),
          ),
          const SizedBox(width: 12),
          _stepBtn(Icons.add_rounded, value < max, () {
            if (value < max) onChanged(value + 1);
          }),
        ],
      );

  Widget _stepBtn(IconData icon, bool enabled, VoidCallback onTap) => GestureDetector(
        onTap: enabled ? onTap : null,
        child: Container(
          width: 32,
          height: 32,
          decoration: BoxDecoration(
            color: enabled ? AppColors.surface : AppColors.card,
            borderRadius: BorderRadius.circular(8),
            border: Border.all(color: enabled ? AppColors.divider : AppColors.divider.withValues(alpha: 0.3)),
          ),
          child: Icon(icon, color: enabled ? AppColors.textPrimary : AppColors.textSecondary, size: 16),
        ),
      );

  Widget _durationPicker({
    required int value,
    required void Function(int) onChanged,
  }) {
    final options = [15, 30, 45, 60, 90, 120];
    return DropdownButton<int>(
      value: options.contains(value) ? value : options.first,
      dropdownColor: AppColors.surface,
      underline: const SizedBox(),
      style: const TextStyle(color: AppColors.textPrimary, fontSize: 16, fontWeight: FontWeight.w700),
      items: options
          .map((v) => DropdownMenuItem(
                value: v,
                child: Text('${v}s'),
              ))
          .toList(),
      onChanged: (v) => onChanged(v!),
    );
  }
}

class _SetCard extends StatefulWidget {
  final int index;
  final WorkoutSet set;
  final bool canDelete;
  final void Function(WorkoutSet) onChanged;
  final VoidCallback onDelete;

  const _SetCard({
    required this.index,
    required this.set,
    required this.canDelete,
    required this.onChanged,
    required this.onDelete,
  });

  @override
  State<_SetCard> createState() => _SetCardState();
}

class _SetCardState extends State<_SetCard> {
  late TextEditingController _workHourCtrl;
  late TextEditingController _workMinCtrl;
  late TextEditingController _workSecCtrl;
  late TextEditingController _breakMinCtrl;
  late TextEditingController _breakSecCtrl;

  @override
  void initState() {
    super.initState();
    final workHour = widget.set.durationSeconds ~/ 3600;
    final workMin = (widget.set.durationSeconds % 3600) ~/ 60;
    final workSec = widget.set.durationSeconds % 60;
    final breakMin = widget.set.breakSeconds ~/ 60;
    final breakSec = widget.set.breakSeconds % 60;

    _workHourCtrl = TextEditingController(text: workHour > 0 ? workHour.toString() : '');
    _workMinCtrl = TextEditingController(text: workMin > 0 ? workMin.toString() : '');
    _workSecCtrl = TextEditingController(text: workSec > 0 ? workSec.toString() : (workHour == 0 && workMin == 0 ? '30' : ''));
    _breakMinCtrl = TextEditingController(text: breakMin > 0 ? breakMin.toString() : '');
    _breakSecCtrl = TextEditingController(text: breakSec > 0 ? breakSec.toString() : (breakMin == 0 ? '10' : ''));
  }

  @override
  void dispose() {
    _workHourCtrl.dispose();
    _workMinCtrl.dispose();
    _workSecCtrl.dispose();
    _breakMinCtrl.dispose();
    _breakSecCtrl.dispose();
    super.dispose();
  }

  void _updateWork() {
    final hour = int.tryParse(_workHourCtrl.text) ?? 0;
    final min = int.tryParse(_workMinCtrl.text) ?? 0;
    final sec = int.tryParse(_workSecCtrl.text) ?? 0;
    final totalSeconds = hour * 3600 + min * 60 + sec;

    final clampedSeconds = totalSeconds > 7200 ? 7200 : totalSeconds;
    widget.onChanged(widget.set.copyWith(durationSeconds: clampedSeconds));

    if (totalSeconds > 7200) {
      _workHourCtrl.text = '2';
      _workMinCtrl.text = '00';
      _workSecCtrl.text = '00';
    }
  }

  void _updateBreak() {
    final min = int.tryParse(_breakMinCtrl.text) ?? 0;
    final sec = int.tryParse(_breakSecCtrl.text) ?? 0;
    final totalSeconds = min * 60 + sec;

    final clampedSeconds = totalSeconds > 3599 ? 3599 : totalSeconds;
    widget.onChanged(widget.set.copyWith(breakSeconds: clampedSeconds));

    if (totalSeconds > 3599) {
      _breakMinCtrl.text = '59';
      _breakSecCtrl.text = '59';
    }
  }

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.only(bottom: 10),
        child: Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: AppColors.card,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: AppColors.accentGreen.withValues(alpha: 0.15)),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    width: 28,
                    height: 28,
                    decoration: BoxDecoration(
                      color: AppColors.accentGreen.withValues(alpha: 0.15),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Center(
                      child: Text(
                        '${widget.index + 1}',
                        style: const TextStyle(
                          color: AppColors.accentGreen,
                          fontSize: 13,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ),
                  ),
                  Expanded(
                    child: TextFormField(
                      initialValue: widget.set.name,
                      style: const TextStyle(color: AppColors.textPrimary, fontSize: 13),
                      maxLength: 30,
                      decoration: const InputDecoration(
                        hintText: 'Exercise name (optional)',
                        hintStyle: TextStyle(color: AppColors.textSecondary, fontSize: 12),
                        isDense: true,
                        contentPadding: EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                        counterText: '',
                      ),
                      onChanged: (v) => widget.onChanged(widget.set.copyWith(name: v)),
                    ),
                  ),
                  if (widget.canDelete) ...[
                    const SizedBox(width: 12),
                    GestureDetector(
                      onTap: widget.onDelete,
                      behavior: HitTestBehavior.opaque,
                      child: Container(
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          color: AppColors.accentOrange.withValues(alpha: 0.1),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: const Icon(
                          Icons.delete_outline_rounded,
                          color: AppColors.accentOrange,
                          size: 20,
                        ),
                      ),
                    ),
                  ],
                ],
              ),
              const SizedBox(height: 12),
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: AppColors.card,
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: AppColors.divider.withValues(alpha: 0.5)),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(8),
                          decoration: BoxDecoration(
                            color: AppColors.accent.withValues(alpha: 0.1),
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: const Icon(Icons.fitness_center_rounded, color: AppColors.accent, size: 16),
                        ),
                        const SizedBox(width: 12),
                        const Text(
                          'Work Time',
                          style: TextStyle(
                            color: AppColors.textPrimary,
                            fontSize: 14,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    _WorkTimePicker(
                      hourController: _workHourCtrl,
                      minController: _workMinCtrl,
                      secController: _workSecCtrl,
                      onChanged: _updateWork,
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 12),
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: AppColors.card,
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: AppColors.divider.withValues(alpha: 0.5)),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(8),
                          decoration: BoxDecoration(
                            color: AppColors.accentOrange.withValues(alpha: 0.1),
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: const Icon(Icons.coffee_rounded, color: AppColors.accentOrange, size: 16),
                        ),
                        const SizedBox(width: 12),
                        const Text(
                          'Break Time',
                          style: TextStyle(
                            color: AppColors.textPrimary,
                            fontSize: 14,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    _BreakTimePicker(
                      minController: _breakMinCtrl,
                      secController: _breakSecCtrl,
                      onChanged: _updateBreak,
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      );
}

class _WorkTimePicker extends StatelessWidget {
  final TextEditingController hourController;
  final TextEditingController minController;
  final TextEditingController secController;
  final VoidCallback onChanged;

  const _WorkTimePicker({
    required this.hourController,
    required this.minController,
    required this.secController,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: AppColors.surface,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: AppColors.divider.withValues(alpha: 0.3)),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            _buildTimeUnit(
              controller: hourController,
              label: 'Hour',
              hint: '0',
              maxLength: 1,
            ),
            const Padding(
              padding: EdgeInsets.only(bottom: 18),
              child: Text(':', style: TextStyle(color: AppColors.textSecondary, fontSize: 24, fontWeight: FontWeight.w600)),
            ),
            _buildTimeUnit(
              controller: minController,
              label: 'Min',
              hint: '00',
              maxLength: 2,
            ),
            const Padding(
              padding: EdgeInsets.only(bottom: 18),
              child: Text(':', style: TextStyle(color: AppColors.textSecondary, fontSize: 24, fontWeight: FontWeight.w600)),
            ),
            _buildTimeUnit(
              controller: secController,
              label: 'Sec',
              hint: '00',
              maxLength: 2,
            ),
          ],
        ),
      );

  Widget _buildTimeUnit({
    required TextEditingController controller,
    required String label,
    required String hint,
    required int maxLength,
  }) =>
      Column(
        children: [
          Container(
            width: maxLength == 1 ? 48 : 64,
            height: 64,
            decoration: BoxDecoration(
              color: AppColors.card,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: AppColors.divider),
            ),
            child: Center(
              child: TextField(
                controller: controller,
                keyboardType: TextInputType.number,
                textAlign: TextAlign.center,
                style: const TextStyle(
                  color: AppColors.textPrimary,
                  fontSize: 28,
                  fontWeight: FontWeight.w700,
                ),
                decoration: InputDecoration(
                  isDense: true,
                  border: InputBorder.none,
                  contentPadding: EdgeInsets.zero,
                  hintText: hint,
                  hintStyle: const TextStyle(
                    color: AppColors.textSecondary,
                    fontSize: 28,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                inputFormatters: [
                  FilteringTextInputFormatter.digitsOnly,
                  LengthLimitingTextInputFormatter(maxLength),
                ],
                onChanged: (_) => onChanged(),
              ),
            ),
          ),
          const SizedBox(height: 8),
          Text(
            label,
            style: const TextStyle(
              color: AppColors.textSecondary,
              fontSize: 11,
              fontWeight: FontWeight.w500,
            ),
          ),
        ],
      );
}

class _BreakTimePicker extends StatelessWidget {
  final TextEditingController minController;
  final TextEditingController secController;
  final VoidCallback onChanged;

  const _BreakTimePicker({
    required this.minController,
    required this.secController,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: AppColors.surface,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: AppColors.divider.withValues(alpha: 0.3)),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            _buildTimeUnit(
              controller: minController,
              label: 'Min',
              hint: '00',
              maxLength: 2,
            ),
            const Padding(
              padding: EdgeInsets.only(bottom: 18, left: 12, right: 12),
              child: Text(':', style: TextStyle(color: AppColors.textSecondary, fontSize: 24, fontWeight: FontWeight.w600)),
            ),
            _buildTimeUnit(
              controller: secController,
              label: 'Sec',
              hint: '00',
              maxLength: 2,
            ),
          ],
        ),
      );

  Widget _buildTimeUnit({
    required TextEditingController controller,
    required String label,
    required String hint,
    required int maxLength,
  }) =>
      Column(
        children: [
          Container(
            width: 72,
            height: 64,
            decoration: BoxDecoration(
              color: AppColors.card,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: AppColors.divider),
            ),
            child: Center(
              child: TextField(
                controller: controller,
                keyboardType: TextInputType.number,
                textAlign: TextAlign.center,
                style: const TextStyle(
                  color: AppColors.textPrimary,
                  fontSize: 28,
                  fontWeight: FontWeight.w700,
                ),
                decoration: InputDecoration(
                  isDense: true,
                  border: InputBorder.none,
                  contentPadding: EdgeInsets.zero,
                  hintText: hint,
                  hintStyle: const TextStyle(
                    color: AppColors.textSecondary,
                    fontSize: 28,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                inputFormatters: [
                  FilteringTextInputFormatter.digitsOnly,
                  LengthLimitingTextInputFormatter(maxLength),
                ],
                onChanged: (_) => onChanged(),
              ),
            ),
          ),
          const SizedBox(height: 7),
          Text(
            label,
            style: const TextStyle(
              color: AppColors.textSecondary,
              fontSize: 11,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      );
}
