import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../theme/app_theme.dart';
import '../models/workout_model.dart';
import '../widgets/common_widgets.dart';
import '../widgets/battery_optimization_dialog.dart';
import 'live_timer_screen.dart';
import 'workout_builder_screen.dart';
import 'history_screen.dart';
import 'settings_screen.dart';

class HomeScreen extends StatefulWidget {
  final List<WorkoutHistory> history;
  final List<Workout> customWorkouts;
  final void Function(WorkoutHistory) onWorkoutComplete;
  final void Function(Workout) onSaveWorkout;
  final void Function(String) onDeleteWorkout;

  const HomeScreen({
    super.key,
    required this.history,
    required this.customWorkouts,
    required this.onWorkoutComplete,
    required this.onSaveWorkout,
    required this.onDeleteWorkout,
  });

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> with TickerProviderStateMixin {
  late AnimationController _headerCtrl;
  late Animation<double> _headerFade;
  String _selectedCategory = 'All';
  int _navIndex = 0;

  final _categories = ['All', 'HIIT', 'Tabata', 'Circuit', 'Beginner', 'Custom'];

  @override
  void initState() {
    super.initState();
    _headerCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 800));
    _headerFade = CurvedAnimation(parent: _headerCtrl, curve: Curves.easeOut);
    _headerCtrl.forward();
    _showFirstTimeHelp();
  }

  void _showFirstTimeHelp() async {
    final prefs = await SharedPreferences.getInstance();
    final shown = prefs.getBool('first_time_help') ?? false;
    if (!shown && mounted) {
      Future.delayed(const Duration(milliseconds: 800), () {
        if (mounted) {
          InfoSnackBar.show(
            context,
            'Tap any workout to see details before starting! 💡',
          );
          prefs.setBool('first_time_help', true);
        }
      });
    }
  }

  @override
  void dispose() {
    _headerCtrl.dispose();
    super.dispose();
  }

  List<Workout> get _filteredWorkouts {
    final all = [...predefinedWorkouts, ...widget.customWorkouts];
    if (_selectedCategory == 'All') return all;
    if (_selectedCategory == 'Custom') return widget.customWorkouts;
    return all.where((w) => w.category == _selectedCategory).toList();
  }

  void _showProfileSheet() {
    showModalBottomSheet(
      context: context,
      backgroundColor: AppColors.surface,
      isDismissible: true,
      enableDrag: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (sheetContext) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 40, height: 4,
                decoration: BoxDecoration(
                  color: AppColors.divider,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
              const SizedBox(height: 24),
              Container(
                width: 72, height: 72,
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [AppColors.accent, AppColors.accentPurple],
                  ),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: const Icon(Icons.person_rounded, color: AppColors.bg, size: 40),
              ),
              const SizedBox(height: 16),
              const Text(
                'Athlete',
                style: TextStyle(color: AppColors.textPrimary, fontSize: 20, fontWeight: FontWeight.w800),
              ),
              const SizedBox(height: 4),
              Text(
                '${widget.history.length} workouts completed',
                style: const TextStyle(color: AppColors.textSecondary, fontSize: 14),
              ),
              const SizedBox(height: 24),
              SizedBox(
                width: double.infinity,
                child: TextButton(
                  onPressed: () => Navigator.pop(sheetContext),
                  style: TextButton.styleFrom(
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                    backgroundColor: AppColors.card,
                  ),
                  child: const Text('Close', style: TextStyle(color: AppColors.textPrimary)),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _startWorkout(Workout workout) {
    showDialog(
      context: context,
      builder: (_) => WorkoutPreviewDialog(
        workout: workout,
        onStart: () async {
          // Show battery optimization dialog on first workout
          await BatteryOptimizationDialog.show(context);
          
          if (!mounted) return;
          
          Navigator.push(
            context,
            PageRouteBuilder(
              pageBuilder: (_, a, b) => LiveTimerScreen(
                workout: workout,
                onComplete: widget.onWorkoutComplete,
              ),
              transitionsBuilder: (_, a, b, child) => SlideTransition(
                position: Tween(begin: const Offset(0, 1), end: Offset.zero)
                    .animate(CurvedAnimation(parent: a, curve: Curves.easeOutCubic)),
                child: child,
              ),
              transitionDuration: const Duration(milliseconds: 400),
            ),
          );
        },
      ),
    );
  }

  void _openBuilder({Workout? workout}) async {
    final result = await Navigator.push<Workout>(
      context,
      PageRouteBuilder(
        pageBuilder: (_, a, b) => WorkoutBuilderScreen(workout: workout),
        transitionsBuilder: (_, a, b, child) => SlideTransition(
          position: Tween(begin: const Offset(1, 0), end: Offset.zero)
              .animate(CurvedAnimation(parent: a, curve: Curves.easeOutCubic)),
          child: child,
        ),
        transitionDuration: const Duration(milliseconds: 350),
      ),
    );
    if (result != null) widget.onSaveWorkout(result);
  }

  @override
  Widget build(BuildContext context) {
    final isWide = MediaQuery.of(context).size.width > 700;

    return Scaffold(
      backgroundColor: AppColors.bg,
      body: IndexedStack(
        index: _navIndex,
        children: [
          _buildHomeTab(isWide),
          WorkoutBuilderScreen(
            key: ValueKey(_navIndex),
            onSave: widget.onSaveWorkout,
            embedded: true,
          ),
          HistoryScreen(history: widget.history),
          const SettingsScreen(),
        ],
      ),
      bottomNavigationBar: _buildNavBar(),
      floatingActionButton: _navIndex == 0
          ? ModernTooltip(
              message: 'Create new workout',
              child: FloatingActionButton(
                onPressed: () => _openBuilder(),
                backgroundColor: AppColors.accent,
                foregroundColor: AppColors.bg,
                elevation: 8,
                child: const Icon(Icons.add_rounded, size: 28),
              ),
            )
          : null,
    );
  }

  Widget _buildNavBar() => Container(
        decoration: BoxDecoration(
          color: AppColors.surface,
          border: const Border(top: BorderSide(color: AppColors.divider)),
        ),
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 8),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                _navItem(0, Icons.home_rounded, 'Home'),
                _navItem(1, Icons.fitness_center_rounded, 'Builder'),
                _navItem(2, Icons.history_rounded, 'History'),
                _navItem(3, Icons.settings_rounded, 'Settings'),
              ],
            ),
          ),
        ),
      );

  Widget _navItem(int index, IconData icon, String label) {
    final active = _navIndex == index;
    return GestureDetector(
      onTap: () {
        setState(() {
          _navIndex = index;
          if (index == 0) {
            _selectedCategory = 'All';
          }
        });
      },
      behavior: HitTestBehavior.opaque,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
        decoration: BoxDecoration(
          color: active ? AppColors.accent.withValues(alpha: 0.15) : Colors.transparent,
          borderRadius: BorderRadius.circular(12),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, color: active ? AppColors.accent : AppColors.textSecondary, size: 24),
            const SizedBox(height: 4),
            Text(
              label,
              style: TextStyle(
                color: active ? AppColors.accent : AppColors.textSecondary,
                fontSize: 11,
                fontWeight: active ? FontWeight.w700 : FontWeight.w500,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildHomeTab(bool isWide) {
    final hasWorkouts = _filteredWorkouts.isNotEmpty;

    return CustomScrollView(
      slivers: [
        _buildSliverHeader(),
        SliverToBoxAdapter(child: _buildStatsRow()),
        if (hasWorkouts) SliverToBoxAdapter(child: _buildQuickStart()),
        if (hasWorkouts) SliverToBoxAdapter(child: _buildCategoryFilter()),
        if (hasWorkouts)
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(20, 0, 20, 8),
              child: Text(
                'Workouts',
                style: TextStyle(
                  color: AppColors.textPrimary,
                  fontSize: 18,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
          ),
        if (hasWorkouts)
          isWide ? _buildWorkoutGrid() : _buildWorkoutList()
        else
          SliverFillRemaining(
            child: EmptyStateWidget(
              emoji: '💪',
              title: 'No Workouts Yet',
              subtitle: 'Create your first workout to get started!\nTap the + button below',
              actionLabel: 'Create Workout',
              onAction: () => _openBuilder(),
            ),
          ),
        const SliverToBoxAdapter(child: SizedBox(height: 100)),
      ],
    );
  }

  Widget _buildSliverHeader() => SliverToBoxAdapter(
        child: FadeTransition(
          opacity: _headerFade,
          child: Container(
            padding: EdgeInsets.fromLTRB(
              20,
              MediaQuery.of(context).padding.top + 20,
              20,
              24,
            ),
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [Color(0xFF131929), AppColors.bg],
              ),
            ),
            child: Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        _greeting(),
                        style: const TextStyle(color: AppColors.textSecondary, fontSize: 14),
                      ),
                      const SizedBox(height: 4),
                      const Text(
                        'Ready to Train? 💪',
                        style: TextStyle(
                          color: AppColors.textPrimary,
                          fontSize: 26,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                    ],
                  ),
                ),
                GestureDetector(
                  onTap: () => _showProfileSheet(),
                  child: Container(
                    width: 48,
                    height: 48,
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(
                        colors: [AppColors.accent, AppColors.accentPurple],
                      ),
                      borderRadius: BorderRadius.circular(14),
                    ),
                    child: const Icon(Icons.person_rounded, color: AppColors.bg, size: 26),
                  ),
                ),
              ],
            ),
          ),
        ),
      );

  String _greeting() {
    final h = DateTime.now().hour;
    if (h < 12) return 'Good Morning ☀️';
    if (h < 17) return 'Good Afternoon 🌤️';
    return 'Good Evening 🌙';
  }

  Widget _buildStatsRow() {
    final totalWorkouts = widget.history.length;
    final totalMins = widget.history.fold(0, (s, h) => s + h.durationSeconds) ~/ 60;
    final streak = _calculateStreak();

    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 0, 20, 24),
      child: Row(
        children: [
          Expanded(
            child: StatCard(
              value: '$totalWorkouts',
              label: 'Workouts',
              icon: Icons.fitness_center_rounded,
              color: AppColors.accent,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: StatCard(
              value: '${totalMins}m',
              label: 'Total Time',
              icon: Icons.timer_rounded,
              color: AppColors.accentGreen,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: StatCard(
              value: '$streak🔥',
              label: 'Day Streak',
              icon: Icons.local_fire_department_rounded,
              color: AppColors.accentOrange,
            ),
          ),
        ],
      ),
    );
  }

  int _calculateStreak() {
    if (widget.history.isEmpty) return 0;
    final uniqueDays = <DateTime>{};
    for (final item in widget.history) {
      uniqueDays.add(DateTime(item.date.year, item.date.month, item.date.day));
    }

    final sorted = uniqueDays.toList()..sort((a, b) => b.compareTo(a));
    int streak = 0;
    DateTime check = DateTime.now();

    for (final day in sorted) {
      final normalizedCheck = DateTime(check.year, check.month, check.day);
      final diff = normalizedCheck.difference(day).inDays;
      if (diff <= 1) {
        streak++;
        check = day;
      } else {
        break;
      }
    }
    return streak;
  }

  Widget _buildQuickStart() {
    final recent = widget.history.isNotEmpty
        ? ([...widget.history]..sort((a, b) => b.date.compareTo(a.date))).first
        : null;
    final allWorkouts = [...predefinedWorkouts, ...widget.customWorkouts];
    if (allWorkouts.isEmpty) return const SizedBox.shrink();
    final quickWorkout = recent != null
        ? allWorkouts.where((w) => w.name == recent.workoutName).firstOrNull ?? allWorkouts.first
        : allWorkouts.first;

    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 0, 20, 24),
      child: GestureDetector(
        onTap: () => _startWorkout(quickWorkout),
        child: Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              colors: [Color(0x2000E5FF), Color(0x207C4DFF)],
            ),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: AppColors.accent.withValues(alpha: 0.3)),
          ),
          child: Row(
            children: [
              Text(quickWorkout.emoji, style: const TextStyle(fontSize: 40)),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'Quick Start',
                      style: TextStyle(color: AppColors.textSecondary, fontSize: 12),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      quickWorkout.name,
                      style: const TextStyle(
                        color: AppColors.textPrimary,
                        fontSize: 18,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      '${quickWorkout.rounds} rounds · ${quickWorkout.sets.length} sets · ${quickWorkout.totalDuration}',
                      style: const TextStyle(color: AppColors.textSecondary, fontSize: 13),
                    ),
                  ],
                ),
              ),
              Container(
                width: 48,
                height: 48,
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [AppColors.accent, AppColors.accentPurple],
                  ),
                  borderRadius: BorderRadius.circular(14),
                ),
                child: const Icon(Icons.play_arrow_rounded, color: AppColors.bg, size: 28),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildCategoryFilter() => Padding(
        padding: const EdgeInsets.only(bottom: 16),
        child: SizedBox(
          height: 40,
          child: ListView.separated(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 20),
            itemCount: _categories.length,
            separatorBuilder: (_, __) => const SizedBox(width: 8),
            itemBuilder: (_, i) => WorkoutCategoryChip(
              label: _categories[i],
              selected: _selectedCategory == _categories[i],
              onTap: () => setState(() => _selectedCategory = _categories[i]),
            ),
          ),
        ),
      );

  Widget _buildWorkoutList() => SliverList(
        delegate: SliverChildBuilderDelegate(
          (ctx, i) => _WorkoutCard(
            workout: _filteredWorkouts[i],
            onStart: () => _startWorkout(_filteredWorkouts[i]),
            onEdit: widget.customWorkouts.contains(_filteredWorkouts[i])
                ? () => _openBuilder(workout: _filteredWorkouts[i])
                : null,
            onDelete: widget.customWorkouts.contains(_filteredWorkouts[i])
                ? () => widget.onDeleteWorkout(_filteredWorkouts[i].id)
                : null,
            index: i,
          ),
          childCount: _filteredWorkouts.length,
        ),
      );

  Widget _buildWorkoutGrid() => SliverPadding(
        padding: const EdgeInsets.symmetric(horizontal: 20),
        sliver: SliverGrid(
          gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(
            maxCrossAxisExtent: 340,
            mainAxisSpacing: 12,
            crossAxisSpacing: 12,
            childAspectRatio: 1.6,
          ),
          delegate: SliverChildBuilderDelegate(
            (ctx, i) => _WorkoutCard(
              workout: _filteredWorkouts[i],
              onStart: () => _startWorkout(_filteredWorkouts[i]),
              onEdit: widget.customWorkouts.contains(_filteredWorkouts[i])
                  ? () => _openBuilder(workout: _filteredWorkouts[i])
                  : null,
              onDelete: widget.customWorkouts.contains(_filteredWorkouts[i])
                  ? () => widget.onDeleteWorkout(_filteredWorkouts[i].id)
                  : null,
              index: i,
            ),
            childCount: _filteredWorkouts.length,
          ),
        ),
      );
}

class _WorkoutCard extends StatefulWidget {
  final Workout workout;
  final VoidCallback onStart;
  final VoidCallback? onEdit;
  final VoidCallback? onDelete;
  final int index;

  const _WorkoutCard({
    required this.workout,
    required this.onStart,
    this.onEdit,
    this.onDelete,
    required this.index,
  });

  @override
  State<_WorkoutCard> createState() => _WorkoutCardState();
}

class _WorkoutCardState extends State<_WorkoutCard> with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<Offset> _slide;
  late Animation<double> _fade;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
      vsync: this,
      duration: Duration(milliseconds: 400 + widget.index * 80),
    );
    _slide = Tween(begin: const Offset(0, 0.3), end: Offset.zero)
        .animate(CurvedAnimation(parent: _ctrl, curve: Curves.easeOutCubic));
    _fade = CurvedAnimation(parent: _ctrl, curve: Curves.easeOut);
    Future.delayed(Duration(milliseconds: widget.index * 60), () {
      if (mounted) _ctrl.forward();
    });
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  static const _categoryColors = {
    'HIIT': AppColors.accentOrange,
    'Tabata': AppColors.accentPurple,
    'Circuit': AppColors.accentGreen,
    'Beginner': AppColors.accent,
    'Custom': Color(0xFFFF6B9D),
  };

  @override
  Widget build(BuildContext context) {
    final color = _categoryColors[widget.workout.category] ?? AppColors.accent;

    return FadeTransition(
      opacity: _fade,
      child: SlideTransition(
        position: _slide,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 0, 20, 12),
          child: Container(
            decoration: BoxDecoration(
              color: AppColors.card,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: color.withValues(alpha: 0.15)),
            ),
            child: Material(
              color: Colors.transparent,
              child: InkWell(
                borderRadius: BorderRadius.circular(20),
                onTap: widget.onStart,
                splashColor: color.withValues(alpha: 0.1),
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Row(
                    children: [
                      Container(
                        width: 56,
                        height: 56,
                        decoration: BoxDecoration(
                          color: color.withValues(alpha: 0.15),
                          borderRadius: BorderRadius.circular(16),
                        ),
                        child: Center(
                          child: Text(
                            widget.workout.emoji,
                            style: const TextStyle(fontSize: 26),
                          ),
                        ),
                      ),
                      const SizedBox(width: 14),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                Expanded(
                                  child: Text(
                                    widget.workout.name,
                                    style: const TextStyle(
                                      color: AppColors.textPrimary,
                                      fontSize: 16,
                                      fontWeight: FontWeight.w700,
                                    ),
                                  ),
                                ),
                                Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                                  decoration: BoxDecoration(
                                    color: widget.workout.difficultyColor.withValues(alpha: 0.15),
                                    borderRadius: BorderRadius.circular(6),
                                  ),
                                  child: Text(
                                    widget.workout.difficulty,
                                    style: TextStyle(
                                      color: widget.workout.difficultyColor,
                                      fontSize: 10,
                                      fontWeight: FontWeight.w600,
                                    ),
                                  ),
                                ),
                                const SizedBox(width: 6),
                                Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                                  decoration: BoxDecoration(
                                    color: color.withValues(alpha: 0.15),
                                    borderRadius: BorderRadius.circular(8),
                                  ),
                                  child: Text(
                                    widget.workout.category,
                                    style: TextStyle(
                                      color: color,
                                      fontSize: 11,
                                      fontWeight: FontWeight.w600,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 6),
                            Row(
                              children: [
                                _infoChip(Icons.repeat_rounded, '${widget.workout.rounds}R'),
                                const SizedBox(width: 8),
                                _infoChip(Icons.layers_rounded, '${widget.workout.sets.length}S'),
                                const SizedBox(width: 8),
                                _infoChip(Icons.timer_rounded, widget.workout.totalDuration),
                              ],
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(width: 8),
                      Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          GestureDetector(
                            onTap: widget.onStart,
                            child: Container(
                              width: 40,
                              height: 40,
                              decoration: BoxDecoration(
                                gradient: LinearGradient(
                                  colors: [color, color.withValues(alpha: 0.7)],
                                ),
                                borderRadius: BorderRadius.circular(12),
                              ),
                              child: const Icon(Icons.play_arrow_rounded, color: Colors.white, size: 22),
                            ),
                          ),
                          if (widget.onEdit != null || widget.onDelete != null) ...[
                            const SizedBox(height: 6),
                            GestureDetector(
                              onTap: () => _showOptions(context),
                              behavior: HitTestBehavior.opaque,
                              child: Container(
                                width: 40,
                                height: 40,
                                decoration: BoxDecoration(
                                  color: AppColors.surface,
                                  borderRadius: BorderRadius.circular(12),
                                ),
                                child: const Icon(
                                  Icons.more_vert_rounded,
                                  color: AppColors.textSecondary,
                                  size: 20,
                                ),
                              ),
                            ),
                          ],
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _infoChip(IconData icon, String text) => Row(
        children: [
          Icon(icon, color: AppColors.textSecondary, size: 13),
          const SizedBox(width: 3),
          Text(text, style: const TextStyle(color: AppColors.textSecondary, fontSize: 12)),
        ],
      );

  void _showOptions(BuildContext context) {
    showModalBottomSheet(
      context: context,
      backgroundColor: AppColors.surface,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (sheetContext) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const SizedBox(height: 8),
            Container(
              width: 40,
              height: 4,
              decoration: BoxDecoration(
                color: AppColors.divider,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            const SizedBox(height: 16),
            if (widget.onEdit != null)
              ListTile(
                leading: const Icon(Icons.edit_rounded, color: AppColors.accent),
                title: const Text('Edit Workout', style: TextStyle(color: AppColors.textPrimary)),
                onTap: () {
                  Navigator.pop(sheetContext);
                  Future.delayed(const Duration(milliseconds: 300), () {
                    if (widget.onEdit != null) {
                      widget.onEdit!();
                    }
                  });
                },
              ),
            if (widget.onDelete != null)
              ListTile(
                leading: const Icon(Icons.delete_rounded, color: AppColors.accentOrange),
                title: const Text('Delete Workout',
                    style: TextStyle(color: AppColors.accentOrange)),
                onTap: () {
                  Navigator.pop(sheetContext);
                  _confirmDelete(context);
                },
              ),
            const SizedBox(height: 8),
          ],
        ),
      ),
    );
  }
  
  void _confirmDelete(BuildContext context) {
    showDialog(
      context: context,
      builder: (dialogContext) => AlertDialog(
        backgroundColor: AppColors.surface,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: const Text('Delete Workout?', style: TextStyle(color: AppColors.textPrimary)),
        content: Text(
          'Are you sure you want to delete "${widget.workout.name}"? This action cannot be undone.',
          style: const TextStyle(color: AppColors.textSecondary),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext),
            child: const Text('Cancel', style: TextStyle(color: AppColors.textSecondary)),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(dialogContext);
              if (widget.onDelete != null) {
                widget.onDelete!();
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: const Row(
                      children: [
                        Icon(Icons.check_circle_rounded, color: AppColors.success),
                        SizedBox(width: 12),
                        Text('Workout deleted', style: TextStyle(color: AppColors.textPrimary)),
                      ],
                    ),
                    backgroundColor: AppColors.surface,
                    behavior: SnackBarBehavior.floating,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                    margin: const EdgeInsets.all(16),
                    duration: const Duration(seconds: 2),
                  ),
                );
              }
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.accentOrange,
              foregroundColor: Colors.white,
            ),
            child: const Text('Delete'),
          ),
        ],
      ),
    );
  }
}
