import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import '../services/voice_service_new.dart';
import '../services/audio_service.dart';

class VoiceSettingsScreenNew extends StatefulWidget {
  const VoiceSettingsScreenNew({super.key});

  @override
  State<VoiceSettingsScreenNew> createState() => _VoiceSettingsScreenNewState();
}

class _VoiceSettingsScreenNewState extends State<VoiceSettingsScreenNew> {
  final VoiceServiceNew _voice = VoiceServiceNew();
  final AudioService _audio = AudioService();
  bool _enabled = true;
  double _volume = 1.0;
  double _speechRate = 0.52;
  AnnouncementMode _announcementMode = AnnouncementMode.voiceAndBeeps;
  VoiceType _voiceType = VoiceType.female1;
  bool _loading = true;
  bool _testing = false;

  @override
  void initState() {
    super.initState();
    _loadSettings();
  }

  Future<void> _loadSettings() async {
    await _voice.init();
    await _audio.init();
    setState(() {
      _enabled = _voice.enabled;
      _volume = _voice.volume;
      _speechRate = _voice.speechRate;
      _announcementMode = _voice.announcementMode;
      _voiceType = _voice.voiceType;
      _loading = false;
    });
  }

  Future<void> _testVoice() async {
    setState(() => _testing = true);
    debugPrint('=== Test Voice Started ===');
    debugPrint('Announcement Mode: $_announcementMode');
    
    if (_announcementMode == AnnouncementMode.voiceOnly || _announcementMode == AnnouncementMode.voiceAndBeeps) {
      debugPrint('Playing voice...');
      await _voice.speak('This is a test of the voice guidance system. Workout starting in 3, 2, 1.');
      // Wait for voice to complete before playing beeps
      if (_announcementMode == AnnouncementMode.voiceAndBeeps) {
        await Future.delayed(const Duration(milliseconds: 500));
      }
    }
    
    if (_announcementMode == AnnouncementMode.beepsOnly || _announcementMode == AnnouncementMode.voiceAndBeeps) {
      debugPrint('Playing beeps sequence...');
      await _audio.playCountdownBeep();
      await Future.delayed(const Duration(milliseconds: 400));
      await _audio.playCountdownBeep();
      await Future.delayed(const Duration(milliseconds: 400));
      await _audio.playCountdownBeep();
      await Future.delayed(const Duration(milliseconds: 400));
      await _audio.playStartBeep();
      debugPrint('Beeps complete');
    }
    
    debugPrint('=== Test Voice Complete ===');
    setState(() => _testing = false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bg,
      appBar: AppBar(
        backgroundColor: AppColors.bg,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_rounded, color: AppColors.textPrimary),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'Voice Settings',
          style: TextStyle(color: AppColors.textPrimary, fontWeight: FontWeight.w700),
        ),
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator(color: AppColors.accent))
          : ListView(
              padding: const EdgeInsets.all(16),
              children: [
                _buildCard(
                  child: Column(
                    children: [
                      SwitchListTile(
                        tileColor: Colors.transparent,
                        overlayColor: WidgetStateProperty.all(Colors.transparent),
                        value: _enabled,
                        onChanged: (value) async {
                          setState(() => _enabled = value);
                          await _voice.setEnabled(value);
                        },
                        title: const Text(
                          'Voice Guidance',
                          style: TextStyle(color: AppColors.textPrimary, fontWeight: FontWeight.w600),
                        ),
                        subtitle: const Text(
                          'Enable voice announcements during workouts',
                          style: TextStyle(color: AppColors.textSecondary, fontSize: 12),
                        ),
                        activeThumbColor: AppColors.accent,
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 16),
                _buildCard(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Padding(
                        padding: EdgeInsets.all(16),
                        child: Text(
                          'Announcement Type',
                          style: TextStyle(
                            color: AppColors.textPrimary,
                            fontSize: 16,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ),
                      ...AnnouncementMode.values.map((mode) => RadioListTile<AnnouncementMode>(
                            value: mode,
                            groupValue: _announcementMode,
                            onChanged: (value) async {
                              if (value != null) {
                                setState(() => _announcementMode = value);
                                await _voice.setAnnouncementMode(value);
                                // Sync with AudioService
                                final audioType = value == AnnouncementMode.voiceOnly ? AnnouncementType.voiceOnly
                                    : value == AnnouncementMode.beepsOnly ? AnnouncementType.beepsOnly
                                    : value == AnnouncementMode.voiceAndBeeps ? AnnouncementType.voiceAndBeeps
                                    : AnnouncementType.silent;
                                await _audio.setAnnouncementType(audioType);
                              }
                            },
                            title: Text(
                              _voice.getAnnouncementModeName(mode),
                              style: const TextStyle(color: AppColors.textPrimary, fontWeight: FontWeight.w600),
                            ),
                            subtitle: Text(
                              _voice.getAnnouncementModeDescription(mode),
                              style: const TextStyle(color: AppColors.textSecondary, fontSize: 12),
                            ),
                            activeColor: AppColors.accent,
                          )),
                    ],
                  ),
                ),
                const SizedBox(height: 16),
                _buildCard(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Padding(
                        padding: EdgeInsets.all(16),
                        child: Text(
                          'Voice Type',
                          style: TextStyle(
                            color: AppColors.textPrimary,
                            fontSize: 16,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ),
                      ...VoiceType.values.map((type) => RadioListTile<VoiceType>(
                            value: type,
                            groupValue: _voiceType,
                            onChanged: (value) async {
                              if (value != null) {
                                setState(() => _voiceType = value);
                                await _voice.setVoiceType(value);
                              }
                            },
                            title: Text(
                              _voice.getVoiceTypeName(type),
                              style: const TextStyle(color: AppColors.textPrimary, fontWeight: FontWeight.w600),
                            ),
                            activeColor: AppColors.accent,
                          )),
                    ],
                  ),
                ),
                const SizedBox(height: 16),
                _buildCard(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Padding(
                        padding: EdgeInsets.all(16),
                        child: Text(
                          'Voice Controls',
                          style: TextStyle(
                            color: AppColors.textPrimary,
                            fontSize: 16,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ),
                      _buildSlider(
                        label: 'Volume',
                        value: _volume,
                        min: 0.0,
                        max: 1.0,
                        divisions: 10,
                        onChanged: (value) async {
                          setState(() => _volume = value);
                          await _voice.setVolume(value);
                        },
                        valueLabel: '${(_volume * 100).toInt()}%',
                      ),
                      _buildSlider(
                        label: 'Speech Rate',
                        value: _speechRate,
                        min: 0.1,
                        max: 2.0,
                        divisions: 19,
                        onChanged: (value) async {
                          setState(() => _speechRate = value);
                          await _voice.setSpeechRate(value);
                        },
                        valueLabel: '${_speechRate.toStringAsFixed(1)}x',
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 16),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton.icon(
                    onPressed: _testing ? null : _testVoice,
                    icon: _testing
                        ? const SizedBox(
                            width: 20,
                            height: 20,
                            child: CircularProgressIndicator(
                              strokeWidth: 2,
                              valueColor: AlwaysStoppedAnimation<Color>(AppColors.bg),
                            ),
                          )
                        : const Icon(Icons.volume_up_rounded),
                    label: Text(_testing ? 'Playing...' : 'Test Voice'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppColors.accent,
                      foregroundColor: AppColors.bg,
                      disabledBackgroundColor: AppColors.accent.withOpacity(0.7),
                      disabledForegroundColor: AppColors.bg,
                      padding: const EdgeInsets.symmetric(vertical: 16),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                    ),
                  ),
                ),
                const SizedBox(height: 16),
                _buildCard(
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          'Voice Announcements',
                          style: TextStyle(
                            color: AppColors.textPrimary,
                            fontSize: 14,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        const SizedBox(height: 12),
                        _buildAnnouncementItem('Workout start with details'),
                        _buildAnnouncementItem('Round start and end'),
                        _buildAnnouncementItem('Set start and end with names'),
                        _buildAnnouncementItem('Rest periods'),
                        _buildAnnouncementItem('Time remaining (10s, 5s, 3-2-1)'),
                        _buildAnnouncementItem('Halfway point for long sets'),
                        _buildAnnouncementItem('Pause and resume'),
                        _buildAnnouncementItem('Workout completion with stats'),
                      ],
                    ),
                  ),
                ),
              ],
            ),
    );
  }

  Widget _buildCard({required Widget child}) {
    return Container(
      decoration: BoxDecoration(
        color: AppColors.card,
        borderRadius: BorderRadius.circular(20),
      ),
      child: child,
    );
  }

  Widget _buildSlider({
    required String label,
    required double value,
    required double min,
    required double max,
    required int divisions,
    required Function(double) onChanged,
    required String valueLabel,
  }) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                label,
                style: const TextStyle(color: AppColors.textPrimary, fontSize: 14),
              ),
              Text(
                valueLabel,
                style: const TextStyle(
                  color: AppColors.accent,
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
          Slider(
            value: value,
            min: min,
            max: max,
            divisions: divisions,
            onChanged: onChanged,
            activeColor: AppColors.accent,
            inactiveColor: AppColors.divider,
          ),
        ],
      ),
    );
  }

  Widget _buildAnnouncementItem(String text) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          const Icon(Icons.check_circle_rounded, color: AppColors.accentGreen, size: 16),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              text,
              style: const TextStyle(color: AppColors.textSecondary, fontSize: 12),
            ),
          ),
        ],
      ),
    );
  }
}
