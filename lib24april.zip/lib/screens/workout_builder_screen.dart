import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../theme/app_theme.dart';
import '../models/workout_model.dart';
import '../widgets/common_widgets.dart';
import '../services/validation_service.dart';

class WorkoutBuilderScreen extends StatefulWidget {
  final Workout? workout;
  final void Function(Workout)? onSave;
  final bool embedded;

  const WorkoutBuilderScreen({
    super.key,
    this.workout,
    this.onSave,
    this.embedded = false,
  });

  @override
  State<WorkoutBuilderScreen> createState() => _WorkoutBuilderScreenState();
}

class _WorkoutBuilderScreenState extends State<WorkoutBuilderScreen>
    with SingleTickerProviderStateMixin {
  late TextEditingController _nameCtrl;
  late int _rounds;
  late int _roundBreak;
  late List<WorkoutSet> _sets;
  late String _emoji;
  late String _category;
  late AnimationController _fadeCtrl;
  late Animation<double> _fadeAnim;

  final _emojis = ['💪', '🔥', '⚡', '🏋️', '🌟', '🚀', '🎯', '🏃', '🥊', '🧘'];
  final _categories = ['Custom', 'HIIT', 'Tabata', 'Circuit', 'Beginner'];

  @override
  void initState() {
    super.initState();
    final w = widget.workout;
    _nameCtrl = TextEditingController(text: w?.name ?? '');
    _rounds = w?.rounds ?? 3;
    _roundBreak = w?.roundBreakSeconds ?? 60;
    _sets = w?.sets.map((s) => s.copyWith()).toList() ??
        [const WorkoutSet(durationSeconds: 30, breakSeconds: 10)];
    _emoji = w?.emoji ?? '💪';
    _category = w?.category ?? 'Custom';
    _fadeCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 500));
    _fadeAnim = CurvedAnimation(parent: _fadeCtrl, curve: Curves.easeOut);
    _fadeCtrl.forward();
  }

  @override
  void dispose() {
    _nameCtrl.dispose();
    _fadeCtrl.dispose();
    super.dispose();
  }

  void _save() {
    if (_nameCtrl.text.trim().isEmpty) {
      ErrorSnackBar.show(context, 'Please enter a workout name');
      return;
    }
    
    if (_nameCtrl.text.trim().length > 30) {
      ErrorSnackBar.show(context, 'Workout name is too long (max 30 characters)');
      return;
    }
    
    if (_sets.isEmpty) {
      ErrorSnackBar.show(context, 'Please add at least one set');
      return;
    }
    
    if (_sets.length > 20) {
      ErrorSnackBar.show(context, 'Too many sets (max 20 sets)');
      return;
    }
    
    final totalSets = _sets.length * _rounds;
    if (totalSets > 100) {
      ErrorSnackBar.show(context, 'Invalid configuration: Total sets (${_sets.length} sets × $_rounds rounds = $totalSets) exceeds maximum of 100');
      return;
    }
    
    final workout = Workout(
      id: widget.workout?.id ?? DateTime.now().millisecondsSinceEpoch.toString(),
      name: _nameCtrl.text.trim(),
      category: _category,
      rounds: _rounds,
      sets: _sets,
      roundBreakSeconds: _roundBreak,
      emoji: _emoji,
    );
    
    // Validate and sanitize workout data
    if (!ValidationService.isValidWorkout(workout)) {
      ErrorSnackBar.show(context, 'Invalid workout configuration');
      return;
    }
    
    final sanitizedWorkout = ValidationService.sanitizeWorkout(workout);
    
    if (widget.embedded && widget.onSave != null) {
      widget.onSave!(sanitizedWorkout);
      SuccessSnackBar.show(context, widget.workout == null ?  'Workout saved successfully!' :  'Workout updated successfully!');
      _resetForm();
    } else {
      Navigator.pop(context, sanitizedWorkout);
      SuccessSnackBar.show(context,  widget.workout == null ?  'Workout saved successfully!' :  'Workout updated successfully!');

    }
  }
  
  void _resetForm() {
    _nameCtrl.clear();
    setState(() {
      _rounds = 3;
      _roundBreak = 60;
      _sets = [const WorkoutSet(durationSeconds: 30, breakSeconds: 10)];
      _emoji = '💪';
      _category = 'Custom';
    });
  }

  @override
  Widget build(BuildContext context) {
    return FadeTransition(
      opacity: _fadeAnim,
      child: widget.embedded ? _buildBody() : Scaffold(
        backgroundColor: AppColors.bg,
        appBar: AppBar(
          centerTitle: false,
          title: Text(widget.workout == null ? 'New Workout' : 'Edit Workout',style: TextStyle(
            color: AppColors.textPrimary,
            fontSize: 22,
            fontWeight: FontWeight.w800,
          ),),
          actions: [
            Padding(
              padding: const EdgeInsets.only(right: 8),
              child: AnimatedGradientButton(
                label: 'Save',
                icon: Icons.check_rounded,
                onTap: _save,
                colors: const [AppColors.accentGreen, AppColors.accent],
              ),
              // TextButton.icon(
              //   onPressed: _save,
              //   icon: const Icon(Icons.check_rounded, color: AppColors.accent, size: 20),
              //   label: const Text('Save', style: TextStyle(color: AppColors.accent, fontWeight: FontWeight.w700)),
              //   style: TextButton.styleFrom(
              //     padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              //   ),
              // ),
            ),
          ],
        ),
        body: _buildBody(),
      ),
    );
  }

  Widget _buildBody() => CustomScrollView(
        slivers: [
          if (widget.embedded)
            SliverToBoxAdapter(
              child: Padding(
                padding: EdgeInsets.fromLTRB(20, MediaQuery.of(context).padding.top + 20, 20, 0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text(
                      'Builder',
                      style: TextStyle(
                        color: AppColors.textPrimary,
                        fontSize: 28,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    AnimatedGradientButton(
                      label: 'Save',
                      icon: Icons.check_rounded,
                      onTap: _save,
                      colors: const [AppColors.accentGreen, AppColors.accent],
                    ),
                  ],
                ),
              ),
            ),
          SliverToBoxAdapter(child: _buildEmojiPicker()),
          SliverToBoxAdapter(child: _buildNameField()),
          SliverToBoxAdapter(child: _buildCategoryPicker()),
          SliverToBoxAdapter(child: _buildRoundsSection()),
          SliverToBoxAdapter(child: _buildSetsSection()),
          SliverToBoxAdapter(child: _buildRoundBreakSection()),
          SliverToBoxAdapter(child: _buildSummary()),
          const SliverToBoxAdapter(child: SizedBox(height: 100)),
        ],
      );

  Widget _buildEmojiPicker() => Padding(
        padding: const EdgeInsets.fromLTRB(20, 20, 20, 0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Icon', style: TextStyle(color: AppColors.textSecondary, fontSize: 13)),
            const SizedBox(height: 10),
            SizedBox(
              height: 52,
              child: ListView.separated(
                scrollDirection: Axis.horizontal,
                itemCount: _emojis.length,
                separatorBuilder: (_, __) => const SizedBox(width: 8),
                itemBuilder: (_, i) => GestureDetector(
                  onTap: () => setState(() => _emoji = _emojis[i]),
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 200),
                    width: 52,
                    height: 52,
                    decoration: BoxDecoration(
                      color: _emoji == _emojis[i]
                          ? AppColors.accent.withValues(alpha: 0.2)
                          : AppColors.card,
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(
                        color: _emoji == _emojis[i] ? AppColors.accent : AppColors.divider,
                        width: 1.5,
                      ),
                    ),
                    child: Center(
                      child: Text(_emojis[i], style: const TextStyle(fontSize: 24)),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      );

  Widget _buildNameField() => Padding(
        padding: const EdgeInsets.fromLTRB(20, 20, 20, 0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Workout Name', style: TextStyle(color: AppColors.textSecondary, fontSize: 13)),
            const SizedBox(height: 8),
            TextField(
              controller: _nameCtrl,
              style: const TextStyle(color: AppColors.textPrimary, fontSize: 16),
              decoration: InputDecoration(
                hintText: 'e.g. Morning HIIT',
                hintStyle: const TextStyle(color: AppColors.textSecondary),
                errorText: _nameCtrl.text.length > 30 ? 'Name too long (max 30 characters)' : null,
                counterText: '${_nameCtrl.text.length}/30',
                counterStyle: TextStyle(
                  color: _nameCtrl.text.length > 30 ? AppColors.error : AppColors.textSecondary,
                  fontSize: 11,
                ),
              ),
              inputFormatters: [LengthLimitingTextInputFormatter(30)],
              onChanged: (_) => setState(() {}),
            ),
          ],
        ),
      );

  Widget _buildCategoryPicker() => Padding(
        padding: const EdgeInsets.fromLTRB(20, 20, 20, 0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Category', style: TextStyle(color: AppColors.textSecondary, fontSize: 13)),
            const SizedBox(height: 10),
            SizedBox(
              height: 36,
              child: ListView.separated(
                scrollDirection: Axis.horizontal,
                itemCount: _categories.length,
                separatorBuilder: (_, __) => const SizedBox(width: 8),
                itemBuilder: (_, i) => WorkoutCategoryChip(
                  label: _categories[i],
                  selected: _category == _categories[i],
                  onTap: () => setState(() => _category = _categories[i]),
                ),
              ),
            ),
          ],
        ),
      );

  Widget _buildRoundsSection() => Padding(
        padding: const EdgeInsets.fromLTRB(20, 24, 20, 0),
        child: _sectionCard(
          title: 'Rounds',
          icon: Icons.repeat_rounded,
          color: AppColors.accentOrange,
          child: _stepper(
            value: _rounds,
            min: 1,
            max: 20,
            onChanged: (v) => setState(() => _rounds = v),
          ),
        ),
      );

  Widget _buildRoundBreakSection() => Padding(
        padding: const EdgeInsets.fromLTRB(20, 16, 20, 0),
        child: _sectionCard(
          title: 'Break Between Rounds',
          icon: Icons.coffee_rounded,
          color: AppColors.accentPurple,
          child: _durationPicker(
            value: _roundBreak,
            onChanged: (v) => setState(() => _roundBreak = v),
          ),
        ),
      );

  Widget _buildSetsSection() => Padding(
        padding: const EdgeInsets.fromLTRB(20, 16, 20, 0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(6),
                      decoration: BoxDecoration(
                        color: AppColors.accentGreen.withValues(alpha: 0.15),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: const Icon(Icons.layers_rounded, color: AppColors.accentGreen, size: 16),
                    ),
                    const SizedBox(width: 8),
                    const Text(
                      'Sets',
                      style: TextStyle(
                        color: AppColors.textPrimary,
                        fontSize: 16,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ],
                ),
                GestureDetector(
                  onTap: _sets.length < 20 ? () => setState(() => _sets.add(const WorkoutSet())) : null,
                  child: Opacity(
                    opacity: _sets.length < 20 ? 1.0 : 0.5,
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                      decoration: BoxDecoration(
                        color: AppColors.accentGreen.withValues(alpha: 0.15),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: const Row(
                        children: [
                          Icon(Icons.add_rounded, color: AppColors.accentGreen, size: 16),
                          SizedBox(width: 4),
                          Text('Add Set', style: TextStyle(color: AppColors.accentGreen, fontSize: 13, fontWeight: FontWeight.w600)),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            ...List.generate(
              _sets.length,
              (i) => _SetCard(
                index: i,
                set: _sets[i],
                canDelete: _sets.length > 1,
                onChanged: (s) => setState(() => _sets[i] = s),
                onDelete: () => setState(() => _sets.removeAt(i)),
              ),
            ),
          ],
        ),
      );

  Widget _buildSummary() {
    final preview = Workout(
      id: 'preview',
      name: _nameCtrl.text.isEmpty ? 'Workout' : _nameCtrl.text,
      rounds: _rounds,
      sets: _sets,
      roundBreakSeconds: _roundBreak,
      emoji: _emoji,
    );

    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 24, 20, 0),
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [Color(0x2600E5FF), Color(0x267C4DFF)],
              ),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: AppColors.accent.withValues(alpha: 0.2)),
            ),
            child: Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    _summaryItem('Total Time', preview.totalDuration, AppColors.accent),
                    _summaryItem('Sets', '${_sets.length}', AppColors.accentGreen),
                    _summaryItem('Rounds', '$_rounds', AppColors.accentOrange),
                  ],
                ),
                const SizedBox(height: 12),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  decoration: BoxDecoration(
                    color: preview.difficultyColor.withValues(alpha: 0.15),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(Icons.fitness_center_rounded, color: preview.difficultyColor, size: 14),
                      const SizedBox(width: 6),
                      Text(
                        'Difficulty: ${preview.difficulty}',
                        style: TextStyle(
                          color: preview.difficultyColor,
                          fontSize: 12,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _summaryItem(String label, String value, Color color) => Column(
        children: [
          Text(value, style: TextStyle(color: color, fontSize: 22, fontWeight: FontWeight.w800)),
          const SizedBox(height: 4),
          Text(label, style: const TextStyle(color: AppColors.textSecondary, fontSize: 12)),
        ],
      );

  Widget _sectionCard({
    required String title,
    required IconData icon,
    required Color color,
    required Widget child,
  }) =>
      Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: AppColors.card,
          borderRadius: BorderRadius.circular(16),
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: color.withValues(alpha: 0.15),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Icon(icon, color: color, size: 18),
            ),
            const SizedBox(width: 12),
            Text(
              title,
              style: const TextStyle(
                color: AppColors.textPrimary,
                fontSize: 15,
                fontWeight: FontWeight.w600,
              ),
            ),
            const Spacer(),
            child,
          ],
        ),
      );

  Widget _stepper({
    required int value,
    required int min,
    required int max,
    required void Function(int) onChanged,
  }) =>
      Row(
        children: [
          _stepBtn(Icons.remove_rounded, value > min, () {
            if (value > min) onChanged(value - 1);
          }),
          const SizedBox(width: 12),
          Text(
            '$value',
            style: const TextStyle(
              color: AppColors.textPrimary,
              fontSize: 20,
              fontWeight: FontWeight.w800,
            ),
          ),
          const SizedBox(width: 12),
          _stepBtn(Icons.add_rounded, value < max, () {
            if (value < max) onChanged(value + 1);
          }),
        ],
      );

  Widget _stepBtn(IconData icon, bool enabled, VoidCallback onTap) => GestureDetector(
        onTap: enabled ? onTap : null,
        child: Container(
          width: 32,
          height: 32,
          decoration: BoxDecoration(
            color: enabled ? AppColors.surface : AppColors.card,
            borderRadius: BorderRadius.circular(8),
            border: Border.all(color: enabled ? AppColors.divider : AppColors.divider.withValues(alpha: 0.3)),
          ),
          child: Icon(icon, color: enabled ? AppColors.textPrimary : AppColors.textSecondary, size: 16),
        ),
      );

  Widget _durationPicker({
    required int value,
    required void Function(int) onChanged,
  }) {
    final options = [15, 30, 45, 60, 90, 120];
    return DropdownButton<int>(
      value: options.contains(value) ? value : options.first,
      dropdownColor: AppColors.surface,
      underline: const SizedBox(),
      style: const TextStyle(color: AppColors.textPrimary, fontSize: 16, fontWeight: FontWeight.w700),
      items: options
          .map((v) => DropdownMenuItem(
                value: v,
                child: Text('${v}s'),
              ))
          .toList(),
      onChanged: (v) => onChanged(v!),
    );
  }
}

class _SetCard extends StatelessWidget {
  final int index;
  final WorkoutSet set;
  final bool canDelete;
  final void Function(WorkoutSet) onChanged;
  final VoidCallback onDelete;

  const _SetCard({
    required this.index,
    required this.set,
    required this.canDelete,
    required this.onChanged,
    required this.onDelete,
  });

  static const _durations = [10, 15, 20, 30, 40, 45, 60, 90, 120];
  static const _breaks = [0, 5, 10, 15, 20, 30, 45, 60];

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.only(bottom: 10),
        child: Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: AppColors.card,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: AppColors.accentGreen.withValues(alpha: 0.15)),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    width: 28,
                    height: 28,
                    decoration: BoxDecoration(
                      color: AppColors.accentGreen.withValues(alpha: 0.15),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Center(
                      child: Text(
                        '${index + 1}',
                        style: const TextStyle(
                          color: AppColors.accentGreen,
                          fontSize: 13,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ),
                  ),
                  // const SizedBox(width: 10),
                  Expanded(
                    child: TextFormField(
                      initialValue: set.name,
                      style: const TextStyle(color: AppColors.textPrimary, fontSize: 13),
                      maxLength: 30,
                      decoration: const InputDecoration(
                        hintText: 'Exercise name (optional)',
                        hintStyle: TextStyle(color: AppColors.textSecondary, fontSize: 12),
                        isDense: true,
                        contentPadding: EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                        counterText: '',
                      ),
                      onChanged: (v) => onChanged(set.copyWith(name: v)),
                    ),
                  ),
                  if (canDelete) ...[
                    const SizedBox(width: 12),
                    GestureDetector(
                      onTap: onDelete,
                      behavior: HitTestBehavior.opaque,
                      child: Container(
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          color: AppColors.accentOrange.withValues(alpha: 0.1),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: const Icon(
                          Icons.delete_outline_rounded,
                          color: AppColors.accentOrange,
                          size: 20,
                        ),
                      ),
                    ),
                  ],
                ],
              ),
              const SizedBox(height: 10),
              Row(
                children: [
                  const SizedBox(width: 38),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text('Work', style: TextStyle(color: AppColors.textSecondary, fontSize: 11)),
                        const SizedBox(height: 4),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                          decoration: BoxDecoration(
                            color: AppColors.surface,
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: _dropdown(
                            value: _durations.contains(set.durationSeconds) ? set.durationSeconds : _durations.first,
                            options: _durations,
                            suffix: 's',
                            onChanged: (v) => onChanged(set.copyWith(durationSeconds: v)),
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(width: 8),
                  Container(width: 1, height: 40, color: AppColors.divider),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text('Break', style: TextStyle(color: AppColors.textSecondary, fontSize: 11)),
                        const SizedBox(height: 4),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                          decoration: BoxDecoration(
                            color: AppColors.surface,
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: _dropdown(
                            value: _breaks.contains(set.breakSeconds) ? set.breakSeconds : _breaks.first,
                            options: _breaks,
                            suffix: 's',
                            onChanged: (v) => onChanged(set.copyWith(breakSeconds: v)),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      );

  Widget _dropdown({
    required int value,
    required List<int> options,
    required String suffix,
    required void Function(int) onChanged,
  }) =>
      DropdownButton<int>(
        value: value,
        dropdownColor: AppColors.surface,
        underline: const SizedBox(),
        isDense: true,
        style: const TextStyle(
          color: AppColors.textPrimary,
          fontSize: 15,
          fontWeight: FontWeight.w700,
        ),
        items: options
            .map((v) => DropdownMenuItem(value: v, child: Text('$v$suffix')))
            .toList(),
        onChanged: (v) => onChanged(v!),
      );
}
